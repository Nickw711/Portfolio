"""
Nicholas Walsh
SDEV 220 Exercise 3.11 page 88
Returns Numbers Entered In 3, 2, 4, 1, 5 Order
Due Jan 27, 2022
"""

#Declaring Variables
numList = []
numbers = input("Enter a 5 digit number: ")

#if statement to make sure the right amount of numbers are entered
if len(numbers) == 5:

#for statement within the if to take each number and append them into a list
    for number in numbers:
        numList.append(number)

    #prints the numbers in the order given in the directions
    print(numList[2], numList[1], numList[3], numList[0], numList[4])

#elif statements to tell the user whether they entered too many or little numbers
elif len(numbers) > 5:
    print("You entered more than than 5 numbers. Please Restart.")
elif len(numbers) < 5:
    print("You entered less than than 5 numbers. Please Restart.")
