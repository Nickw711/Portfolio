"""
Nicholas Walsh
SDEV 220 Exercise 4.3 page 121
Linear Equation Program
Due Jan 27, 2022
"""

#Allows the user to input all 6 variables
a,b,c,d,e,f = eval(input("Enter a,b,c,d,e,f: "))

#solves the equation as provided by the instructions
if ((a * d) - (b * c)) == 0:
    print("The equation has no solution.")
else:
    x = ((e * d) - (b * f)) / ((a * d) - (b * c))

    y = ((a * f) - (e * c)) / ((a * d) - (b * c))

    if x - y == 0:
        print("X - Y = 0", a,b,c,d,e,f)
    else:
        print("X is", x, "and Y is", y)
