"""
Nicholas Walsh
SDEV 220 Exercise 2.23 page 61
Draws 6 circles in the center of the screen
Due Jan 27, 2022
"""

import turtle

#changed turtle to t for ease of use
t = turtle.Turtle()

#created 6 circles in a straight line down the center
t.circle(50)
t.penup()
t.goto(0, 100)
t.pendown()
t.circle(50)
t.penup()
t.goto(0, 200)
t.pendown()
t.circle(50)
t.penup()
t.goto(0, -100)
t.pendown()
t.circle(50)
t.penup()
t.goto(0, -200)
t.pendown()
t.circle(50)
t.penup()
t.goto(0, -300)
t.pendown()
t.circle(50)
