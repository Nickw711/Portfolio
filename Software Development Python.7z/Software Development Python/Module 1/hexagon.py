"""
Nicholas Walsh
SDEV 220 Exercise 2.15 Page 59
Displays perimeter and area of a hexagon entered
Due Jan 27, 2022
"""

#Declares the variables using user input for the sides and formulas to determine the area and perimeter
side = eval(input("Enter the length of one of the sides of the hexagon: "))
area = ((3 * 1.73205080757) / 2) * (side * side)
perimeter = (area * 6)

#Print statements to print out the area and perimeter based on the length of the side
print("The area of the hexagon is:", area)
print("The perimeter of the hexagon is:", perimeter)
