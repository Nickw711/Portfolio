"""
Nicholas Walsh
SDEV 220 Exercise 1.21 Page 29
Draws a clock showing the time 6:45
Due Jan 27, 2022
"""

#imports turtle
import turtle

#sets t to turtle
t = turtle.Turtle()

#draws a circle with two lines pointing at the time 6:45
t.circle(100)
t.left(90)
t.penup()
t.forward(20)
t.pendown()
t.left(45)
t.forward(5)
t.back(5)
t.right(90)
t.forward(5)
t.back(5)
t.left(45)
t.forward(80)
t.left(90)
t.forward(100)
