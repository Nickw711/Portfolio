"""
Nicholas Walsh
SDEV 220 Exercise 1.9 Page 28
Prints the area and perimeter of a rectangle with user entered dimensions
Due Jan 27, 2022
"""

#User input for the width and height
width = float(input("Enter the width of the rectangle: "))
height = float(input("Enter the height of the rectangle: "))

#Formulas to find the area and perimeter
area = (width * height)
perimeter = (2 * (width + height))

#Print statements for the area and perimeter
print("\nArea:", area)
print("Perimeter:", perimeter)
