"""
Nicholas Walsh
SDEV 220 Exercise 3.1 page 85
Outputs side length and area of a pentagon based of the radius
Due Jan 27, 2022
"""

import math

#user input for the radius
radius = eval(input("Enter the length from the center of a pentagon to a vertex: "))

#math to determine length of each side
side = (float(2 * radius)) * (float(math.sin(math.pi / 5)))

#print statement for the side length
print("The length of each side of the pentagon is", side)

#math to determine area of the pentagon
area = ((3 * math.sqrt(3)) / 2) * (side * side)

#print statement for the area of the pentagon
print("The area of the pentagon is", area)
