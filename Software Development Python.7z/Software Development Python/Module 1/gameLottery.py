"""
Nicholas Walsh
SDEV 220 Exercise 4.15 page 123
Lottery Guessing Game
Due Jan 27, 2022
"""

#import random
import random

#Declare variables used
lottery = random.randint(100, 999)
lottoList = []
ticker = 0
userBalance = 0
userEntry = eval(input("Enter a 3 digit number: "))

if len(str(userEntry)) != 3:
    print("Please enter 3 numbers next time!")
    
else:   
    print(lottery)

#Jackpot if user guessing number correctly in order
    if userEntry == lottery:
        userBalance += 15000
        print("JACKPOT! You guessed all numbers in order correctly and win $15,000!")
        print("Your balance is now:", userBalance)

#Changes lottery and userEntry to string so lottery numbers can be put in a list and compared to the user entry
    else:
        lottery = str(lottery)
        userEntry = str(userEntry)
    
        for number in lottery:
            lottoList.append(number)

#Checks if the numbers in the lottery are the same as the user entered numbers    
        for num in userEntry:
            if num == lottoList[0] or num == lottoList[1] or num == lottoList[2]:
                ticker += 1

#If 3 numbers are the same the user wins 7,500        
        if ticker == 3:
            userBalance += 7500
            print("Congratulations! You guessed all the numbers correctly and won $7,500!")
            print("Your balance is now:", userBalance)

#If 2 numbers are the same the user wins 2,000    
        elif ticker == 2:
            userBalance += 2000
            print("Congratulations! You guessed two numbers correctly and won $2000!")
            print("Your balance is now:", userBalance)

#The user loses if one or less numbers are the same    
        else:
            print("You lose!")
