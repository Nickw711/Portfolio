'''
Nicholas Walsh
SDEV 220 Exercise 10.7 Page 350
Randomly generates numbers 0-9 and keeps track of the amount of each number
in a list.
February 16, 2022
'''
import random
numberList = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]


countList = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
for i in range(1000):
    num = random.randint(0, 9)
    countList[num] += 1


print("Number Order:")
print(numberList)
print("\nQuantity of Each Number:")
print(countList)
