'''
Nicholas Walsh
SDEV 220 Exercise 11.11 Page 385
This program allows the user to enter a number(0-511).
It then turns that number into a 9 digit binary number.
After this, it changes the table to the numbers in order.
Finally, it changes the numbers in the table to either heads or tails.
February 16, 2022
'''
headsTails = [
    [0, 0, 0],
    [0, 0, 0],
    [0, 0, 0],
    ]

def printTable(headsTails):
    for row in range(len(headsTails)):
        for column in range(len(headsTails[row])):
            print(headsTails[row][column], end = " ")
        print()
    startUp()

def chooseNumber(headsTails):
    userInput = input("Enter a number 0-511: ")
    tableInput = f'{int(userInput):09b}'
    
    rowCount = 0
    colCount = 0
    
    for digit in tableInput:
        headsTails[rowCount][colCount] = digit
        
        if headsTails[rowCount][colCount] == "0":
            headsTails[rowCount][colCount] = "H"
        elif headsTails[rowCount][colCount] == "1":
            headsTails[rowCount][colCount] = "T"
            
        if colCount == 2:
            rowCount += 1
            colCount = 0
        else:
            colCount += 1
            
    printTable(headsTails)

def startUp():
    userPlay = input("Would you like to play heads/tails?(Y or N): ")
    if userPlay == "Y" or userPlay == "y":
        chooseNumber(headsTails)
    else:
        exit()

startUp()
