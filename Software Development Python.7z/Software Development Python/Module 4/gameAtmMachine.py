'''
Nicholas Walsh
SDEV 220 Exercise 12.3 Page 429
This program creates an ATM game, allowing the user to enter an id(0-9)
and then edit the bank account of that id. They can get balance, deposit,
withdraw, and exit.
February 16, 2022
'''
class Account():
    def __init__(self, id=0, balance=500):
        self.id = id
        self.balance = balance

    def changeId(self, id):
        self.id = id
        return "Your New ID is: " + str(self.id)

    def getId(self):
        return "Your ID is: " + str(self.id)

    def changeBalance(self, balance):
        self.balance = balance
        return "Your Balance is Now: $" + str(self.balance)

    def getBalance(self):
        return "Your Balance is: $" + str(self.balance)

    def withdraw(self, balance):
        self.balance = self.balance - balance
        return "Your Balance is Now: $" + str(self.balance)

    def deposit(self, balance):
        self.balance += balance
        return "Your Balance is Now: $" + str(self.balance)

    def __str__(self):
        return "ID: " + str(self.id) + "\nBalance: $" + str(self.balance)


class MainMenu(Account):
    def __init__(self):
        accountArray = [A1, A2, A3, A4, A5, A6, A7, A8, A9, A10]
        userId = int(input("Enter an account id: "))
        
        while userId not in [0, 1, 2, 3, 4, 5, 6, 7, 8, 9,]:
            print("Incorrect Id, Please Try Again.")
            userId = int(input("Enter an account id: "))
            
        global user
        user = accountArray[userId]
        MainMenu.userChoice()
        
    def userChoice():

        print("\nMain Menu")
        print("1: Check Balance")
        print("2: Withdraw")
        print("3: Deposit")
        print("4: Exit")
        
        userChoice = input("Enter a choice: ")
        if userChoice == "1":
            print(user.getBalance())
            MainMenu.userChoice()
            
        elif userChoice == "2":
            withdrawAmount = int(input("Enter the amount you want to withdraw: "))
            print(user.withdraw(withdrawAmount))
            MainMenu.userChoice()
            
        elif userChoice == "3":
            depositAmount = int(input("Enter the amount you want to deposit: "))
            print(user.deposit(depositAmount))
            MainMenu.userChoice()
            
        elif userChoice == "4":
            MainMenu()

        else:
            print("Incorrect Choice, Try Again.")
            MainMenu.userChoice()
            

A1 = Account()
A2 = Account(1)
A3 = Account(2)
A4 = Account(3)
A5 = Account(4)
A6 = Account(5)
A7 = Account(6)
A8 = Account(7)
A9 = Account(8)
A10 = Account(9)
MainMenu()
