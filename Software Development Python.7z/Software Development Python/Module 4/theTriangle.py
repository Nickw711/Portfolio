'''
Nicholas Walsh
SDEV 220 Exercise 12.1 Page 428
This program contains a class and a subclass, and also
allows the user to enter all three triangle sides,
color, and whether it's filled or not.
The program then prints all the information into the console.
February 16, 2022
'''
class GeometricObject():
    def __init__(self, color="white", filled=True):
        self.color = color
        self.filled = filled

    def getColor(self):
        return self.color

    def setColor(self, color):
        self.color = color

    def isFilled(self):
        return self.filled

    def setFilled(self, filled):
        if filled == True or filled == False:
            self.filled = filled
        else:
            return "You must enter either True or False"

    def __str__(self):
        return "Color: " + self.color + "\nFilled: " + str(self.filled)

class Triangle(GeometricObject):
    def __init__(self, side1=2, side2=2, side3=2):
        self.side1 = int(side1)
        self.side2 = int(side2)
        self.side3 = int(side3)
    def getArea(self):
        Area = .5 * (self.side1 * self.side2)
        return "Triangle Area: " + str(Area)

    def getPerimeter(self):
        Perimeter = self.side1 + self.side2 + self.side3
        return "Triangle Perimeter: " + str(Perimeter)

    def __str__(self):
        return  "\nTriangle: side1 = "  + str(self.side1)\
        + " side2 = " + str(self.side2) +  " side3 = "  + str(self.side3)
    
def isFilledT():
    global tFilled
    tFilled = input("Enter whether you want the triangle to be filled or not(1 or 0): ")
    if tFilled == "0":
        tFilled = False
    elif tFilled == "1":
        tFilled = True
    else:
        print("Incorrect fill given, please enter either a 1 or 0!")
        isFilledT()

sideA = input("Enter the length of the triangle's first side: ")
sideB = input("Enter the length of the triangle's second side: ")
sideC = input("Enter the length of the triangle's third side: ")
tColor = input("Enter the color of the triangle: ")
isFilledT()
userGeometric = GeometricObject(tColor, tFilled)
userTriangle = Triangle(sideA, sideB, sideC)
print(userTriangle)
print(userTriangle.getArea())
print(userTriangle.getPerimeter())
print(userGeometric)
