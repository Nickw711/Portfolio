'''
Nicholas Walsh
SDEV 220 Exercise 9.17 Page 307
This program has a car that moves across the screen and resets when it
reaches the end of the window. The user can also adjust the speed
of the car by using the up and down arrows on their keyboard.
February 9, 2022
'''
from tkinter import *

class RacingCar:
    def __init__(self):
        root = Tk()
        root.title("Racing Car Animation")
        root.geometry("750x250")

        self.width=750
        self.canvas = Canvas(root, bg="white", width=self.width, height=250)
        self.canvas.pack()

        frame = Frame(root)
        frame.pack()

        root.bind('<Up>', self.increaseSpeed)
        root.bind('<Down>', self.decreaseSpeed)

        self.x = 0
        self.sleepTime = 100
        self.canvas.create_oval(25, 175, 50, 200, fill="black", tags="car")
        self.canvas.create_oval(75, 175, 100, 200, fill="black", tags="car")
        self.canvas.create_rectangle(0,175,125,150, fill="silver", tags="car")
        self.canvas.create_polygon(25,150,50,125,75,125,100,150, fill="grey", tags="car")

        self.dx = 3
        self.isStopped = False
        self.animate()

        root.mainloop()

    def increaseSpeed(self, event):
        if self.sleepTime > 20:
            self.sleepTime -= 20

    def decreaseSpeed(self, event):
        self.sleepTime += 20

    def animate(self):
        while not self.isStopped:
            self.canvas.move("car", self.dx, 0)
            self.canvas.after(self.sleepTime)
            self.canvas.update()
            if self.x < self.width:
                self.x += self.dx
            else:
                self.x = 0
                self.canvas.delete("car")
                self.canvas.create_oval(25, 175, 50, 200, fill="black", tags="car")
                self.canvas.create_oval(75, 175, 100, 200, fill="black", tags="car")
                self.canvas.create_rectangle(0,175,125,150, fill="silver", tags="car")
                self.canvas.create_polygon(25,150,50,125,75,125,100,150, fill="grey", tags="car")

RacingCar()
