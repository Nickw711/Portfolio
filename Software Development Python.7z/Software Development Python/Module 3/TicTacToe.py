'''
Nicholas Walsh
SDEV 220 Exercise 11.9 Page 384
The program runs a Tic Tac Toe game for two players.
February 16, 2022
'''
board = [
    ["| - |", "| - |", "| - |"],
    ["| - |", "| - |", "| - |"],
    ["| - |", "| - |", "| - |"],
    ]

def printBoard(board):
    counter = 0

    print("-----------------")
    for row in board:
        for slot in row:
            counter += 1
            if counter == 3:
                print(slot, end="\n")
                counter = 0
            else:
                print(slot, end=" ")
    print("-----------------")

def xGame(board):
    numList = [1, 2, 3]
    print("\n\t(1, 2, or 3)")
    xRowInput = int(input("Enter Your Row Number For X: "))
    xColInput = int(input("Enter Your Column Number For X: "))
    
    if xRowInput not in numList or xColInput not in numList:
        print("Row or Column Entry is Invalid, Please Re-enter.")
        xGame(board)
    
    if board[xRowInput - 1][xColInput - 1] == "| - |":
        board[xRowInput - 1][xColInput - 1] = "| X |"
        printBoard(board)
        checkWinnerX(board)
    else:
        print("Slot is Already Taken By An X or An O. Please Try Again.")
        xGame(board)

def oGame(board):
    numList = [1, 2, 3]
    print("\n\t(1, 2, or 3)")
    oRowInput = int(input("Enter Your Row Number For O: "))
    oColInput = int(input("Enter Your Column Number For O: "))

    if oRowInput not in numList or oColInput not in numList:
        print("Row or Column Entry is Invalid, Please Re-enter.")
        oGame(board)

    if board[oRowInput - 1][oColInput - 1] == "| - |":
        board[oRowInput - 1][oColInput - 1] = "| O |"
        printBoard(board)
        checkWinnerO(board)
    else:
        print("Slot is Already Taken By An X or An O. Please Try Again.")
        oGame(board)

def checkWinnerX(board):
    if board[0][0] == "| X |" and board[1][1] == "| X |" and board[2][2] == "| X |":
        print("Player X Wins!")
        olaunchGame(board)
    elif board[0][0] == "| X |" and board[0][1] == "| X |" and board[0][2] == "| X |":
        print("Player X Wins!")
        olaunchGame(board)
    elif board[1][0] == "| X |" and board[1][1] == "| X |" and board[1][2] == "| X |":
        print("Player X Wins!")
        olaunchGame(board)
    elif board[2][0] == "| X |" and board[2][1] == "| X |" and board[2][2] == "| X |":
        print("Player X Wins!")
        olaunchGame(board)
    elif board[0][2] == "| X |" and board[1][1] == "| X |" and board[2][0] == "| X |":
        print("Player X Wins!")
        olaunchGame(board)
    elif board[0][0] == "| X |" and board[1][0] == "| X |" and board[2][0] == "| X |":
        print("Player X Wins!")
        olaunchGame(board)
    elif board[0][1] == "| X |" and board[1][1] == "| X |" and board[2][1] == "| X |":
        print("Player X Wins!")
        olaunchGame(board)
    elif board[0][2] == "| X |" and board[1][2] == "| X |" and board[2][2] == "| X |":
        print("Player X Wins!")
        olaunchGame(board)
    else:
        checkDrawX(board)

def checkWinnerO(board):
    if board[0][0] == "| O |" and board[1][1] == "| O |" and board[2][2] == "| O |":
        print("Player O Wins!")
        xlaunchGame(board)
    elif board[0][0] == "| O |" and board[0][1] == "| O |" and board[0][2] == "| O |":
        print("Player X Wins!")
        xlaunchGame(board)
    elif board[1][0] == "| O |" and board[1][1] == "| O |" and board[1][2] == "| O |":
        print("Player O Wins!")
        xlaunchGame(board)
    elif board[2][0] == "| O |" and board[2][1] == "| O |" and board[2][2] == "| O |":
        print("Player O Wins!")
        xlaunchGame(board)
    elif board[0][2] == "| O |" and board[1][1] == "| O |" and board[2][0] == "| O |":
        print("Player O Wins!")
        xlaunchGame(board)
    elif board[0][0] == "| O |" and board[1][0] == "| O |" and board[2][0] == "| O |":
        print("Player O Wins!")
        xlaunchGame(board)
    elif board[0][1] == "| O |" and board[1][1] == "| O |" and board[2][1] == "| O |":
        print("Player O Wins!")
        xlaunchGame(board)
    elif board[0][2] == "| O |" and board[1][2] == "| O |" and board[2][2] == "| O |":
        print("Player O Wins!")
        xlaunchGame(board)
    else:
        checkDrawO(board)

def checkDrawO(board):
    slotCount = 0
    for row in board:
        for slot in row:
            if slot != "| - |":
                slotCount += 1
    if slotCount == 9:
        print("There Has Been A Draw, No One Wins!")
        olaunchGame(board)
    else:
        xGame(board)

def checkDrawX(board):
    slotCount = 0
    for row in board:
        for slot in row:
            if slot != "| - |":
                slotCount += 1
    if slotCount == 9:
        print("There Has Been A Draw, No One Wins!")
        xlaunchGame(board)
    else:
        oGame(board)

def xlaunchGame(board):
    board = [
    ["| - |", "| - |", "| - |"],
    ["| - |", "| - |", "| - |"],
    ["| - |", "| - |", "| - |"],
    ]
    userInput = input("Would you like to play Tic Tac Toe(Y or N): ")
    if userInput == "Y" or userInput == "y":
        printBoard(board)
        xGame(board)
    else:
        quit()

def olaunchGame(board):
    board = [
    ["| - |", "| - |", "| - |"],
    ["| - |", "| - |", "| - |"],
    ["| - |", "| - |", "| - |"],
    ]
    userInput = input("Would you like to play Tic Tac Toe(Y or N): ")
    if userInput == "Y" or userInput == "y":
        printBoard(board)
        oGame(board)
    else:
        quit()

xlaunchGame(board)
