'''
Nicholas Walsh
SDEV 220 Exercise 9.3 Page 304
Allows user to choose to create a triangle or diamond and then fill
said triangle or diamond.
February, 9, 2022
'''
from tkinter import *

Main = Tk()
Main.title("Radiobuttons and Checkbuttons")
Main.geometry("400x400")

canvas = Canvas(Main, width=200, height=200)

def createShape():
    if check1.get() == 't' and check2.get() == 1:
        canvas.delete('all')
        canvas.create_polygon((0,0,100,200,200,0), fill="black")
        canvas.grid(row=0, column=0)
        
    elif check1.get() == 'd' and check2.get() == 1:
        canvas.delete('all')
        canvas.create_polygon((50,100,100,0,150,100,100,200), fill="black")
        canvas.grid(row=0, column=0)

    elif check1.get() == 't' and check2.get() == 0:
        canvas.delete('all')
        canvas.create_polygon((0,0,100,200,200,0), fill="white")
        canvas.grid(row=0, column=0)

    elif check1.get() == 'd' and check2.get() == 0:
        canvas.delete('all')
        canvas.create_polygon((50,100,100,0,150,100,100,200), fill="white")
        canvas.grid(row=0, column=0)

check1 = StringVar()
triangleButton = Radiobutton(Main, text="Triangle", variable=check1, value='t', command=createShape)
triangleButton.grid(row=2, column=0)

diamondButton = Radiobutton(Main, text="Diamond", variable=check1, value='d', command=createShape)
diamondButton.grid(row=2, column=1)

check2 = IntVar()
fillButton = Checkbutton(Main, text="Filled", onvalue=1, variable=check2, command=createShape)
fillButton.grid(row=2, column=2)

Main.mainloop()
