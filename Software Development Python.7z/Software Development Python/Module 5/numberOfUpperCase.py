"""
Nicholas Walsh
SDEV 220 Exercise 5.13 Page 524
Allows user to input a string. Then returns the amount of upper case letters
in the string.
Due February 23, 2022
"""
s = input("Enter a string: ")

def countUppercase(s):
    count = 0
    for letter in s:
        if letter.isupper():
            count += 1
    print (count, "Letters are uppercase from the inputted string.")
countUppercase(s)
    
