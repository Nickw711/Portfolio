"""
Nicholas Walsh
SDEV 220 Exercise 13.5 Page 472
Allows user to input text document. Allows user to replace a certain string
with a new string.
Due February 23, 2022
"""
import re
def openFile():
    fileName = input("Enter a filename: ")
    oldString = input("Enter the old string to be replaced: ")
    newString = input("Enter the new string to replace the old string: ")
    openedFile = open(fileName)
    for line in openedFile:
        print(re.sub(oldString, newString, line), end= '')
    openedFile.read()
    openedFile.close()
openFile()

    
