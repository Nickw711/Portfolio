'''
Nicholas Walsh
SDEV 220 Exercise 18.3
Linked List class with added functions; remove, lastindexOf, and set.
Due March 2, 2022
'''
class linkedList():
    def __init__(self):
        self.list1 = ["Tom", "George", "Peter", "Jean", "Jane"]
    def addAll(self, otherList):
        if otherList == []:
            return "List is empty"
        else:
            for element in otherList:
                self.list1.append(element)
        print(self.list1)
        return True

    def removeAll(self, otherList):
        if otherList == []:
            return "List is empty"
        else:
            for count in range(len(otherList)):
                otherList.pop()
        print("Results:", otherList)
        return True

    def retainAll(self, otherList):
        count = 0
        if otherList == []:
            return "List is empty"
        else:
            for element in otherList:
                if element in self.list1:
                    self.list1.insert(0, element)
                    count += 1
            count = (len(self.list1) - count)
            while count != 0:
                self.list1.pop()
                count -= 1
        print(self.list1)
        return True

    def remove(self, e):
            count = -1
            if e in self.list1:
                    for element in self.list1:
                            count += 1
                            if element == e:
                                    self.list1.pop(count)
                                    break
            else:
                    print("Element not in list")
                    return False
            print(self.list1)
            return True

    def lastindexOf(self):
            count = 0
            if self.list1 == []:
                    print("-1")
                    return False
            for element in self.list1:
                    count +=1
            print("Elements in the list:", count)
            return True


    def set(self, index, o):
            if index > len(self.list1):
                    print ("Out of range")
                    return False
            else:
                    self.list1[index] = o
            print(list1.list1)
            return True
            

list2 = ["Tom", "George", "Michael", "Michelle", "Daniel"]
list3 = []

list1 = linkedList()

#list1.remove("Tom")

#list1.lastindexOf()

#list1.set(3, "Jerry")
