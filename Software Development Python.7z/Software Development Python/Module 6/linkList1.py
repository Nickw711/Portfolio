'''
Nicholas Walsh
SDEV 220 Exercise 18.1
Linked List class that allows the user to add all and retain all
elements from one list to the main list. Also allows the user to remove all
elements from a list.
Due March 2, 2022
'''
class linkedList():
    def __init__(self):
        self.list1 = ["Tom", "George", "Peter", "Jean", "Jane"]
    def addAll(self, otherList):
        if otherList == []:
            return "List is empty"
        else:
            for element in otherList:
                self.list1.append(element)
        print(self.list1)
        return True

    def removeAll(self, otherList):
        if otherList == []:
            return "List is empty"
        else:
            for count in range(len(otherList)):
                otherList.pop()
        print("Results:", otherList)
        return True

    def retainAll(self, otherList):
        count = 0
        if otherList == []:
            return "List is empty"
        else:
            for element in otherList:
                if element in self.list1:
                    self.list1.insert(0, element)
                    count += 1
            count = (len(self.list1) - count)
            while count != 0:
                self.list1.pop()
                count -= 1
        print(self.list1)
        return True   
                

list2 = ["Tom", "George", "Michael", "Michelle", "Daniel"]
list3 = []

list1 = linkedList()

#list1.addAll(list2)

#list1.removeAll(list2)

#list1.retainAll(list2)

#list1.removeAll(list1.list1)
