board = [
    [" - "], [" - "], [" - "],
    [" - "], [" - "], [" - "],
    [" - "], [" - "], [" - "],
    ]

decideTurn = 0

def gameLoop(board, decideTurn):
    startGame = input("Would you like to play tik tak toe? (Y/N): ")
    if startGame == "y" or startGame == "Y":
        if decideTurn == 0:
            xTurn(board)
        else:
            oTurn(board)
    else:
        exit()
    

def xTurn(board):
    firstXInput = input("Player x choose a row: ")
    secondXInput = input("Player x choose a column: ")
    if " - " in board[firstXInput][secondXInput]:
        board[firstXInput][secondXInput] = "X"
        for row in board:
            for column in board:
                if " - " not in column:
                    completeGame()
                else:
                    oTurn(board)
    else:
        print("Slot taken. Try again.")
        xTurn(board)
    
def oTurn(board):
    firstOInput = input("Player o choose a row: ")
    secondOInput = input("Player o choose a column: ")
    if " - " in board[firstOInput][secondOInput]:
        board[firstOInput][secondOInput] = "X"
        for row in board:
            for column in board:
                if " - " not in column:
                    completeGame()
                else:
                    XTurn(board)
    else:
        print("Slot taken. Try again.")
        oTurn(board)

def completeGame():
    print("Good Game!")
gameLoop(board, decideTurn)
