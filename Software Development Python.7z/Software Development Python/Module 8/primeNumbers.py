class Stack:
    def __init__(self):
        self.__elements = []

    # Return true if the tack is empty
    def isEmpty(self):
        return len(self.__elements) == 0
    
    # Returns the element at the top of the stack 
    # without removing it from the stack.
    def peek(self):
        if self.isEmpty():
            return None
        else:
            return self.__elements[len(elements) - 1]

    # Stores an element into the top of the stack
    def push(self, value):
        self.__elements.append(value)

    # Removes the element at the top of the stack and returns it
    def pop(self):
        if self.isEmpty():
            return None
        else:
            '''Changed return to print because the elements wouldn't return on
            the console screen'''
            print(self.__elements.pop())
    
    # Return the size of the stack
    def getSize(self):
        return len(self.__elements)

    '''Pops each element in the stack to print them in decending order'''
    def printStack(self):

        '''Had to stack these for loops on top of each other because for
        some reason it would only loop through half of the list each time'''
        for each in self.__elements:
            self.pop()
        for each in self.__elements:
            self.pop()
        for each in self.__elements:
            self.pop()
        for each in self.__elements:
            self.pop()
        for each in self.__elements:
            self.pop()
        self.pop()


class Prime(Stack):

    '''Check if the number is prime'''
    def isPrime(self, number):
        divisor = 2
        while divisor <= number / 2:
            if number % divisor == 0:
                return False
            divisor += 1
        return True

    '''Finds 50 first prime numbers and pushes them into a stack'''
    def __init__(self):
        amount = 50
        count = 0
        number = 2
        
        while count < amount:
            if self.isPrime(number):
                count += 1
                Stack.push(number)

            number += 1



Stack = Stack()

def main():
    Prime()
    Stack.printStack()

main()
