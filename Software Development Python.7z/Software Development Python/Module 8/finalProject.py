#Authors: Nancy Donathan, Samuel Hardison, Nicolas Walsh, Matt Wolf
#SDEV 220 M08 Final Project
#Write a program based on the childhood game 'hangman', instead of drawing a person, draw a house. See  See exercise 14.9 on page 497-498 for an example.
#Due: 3/15/22


import random
from tkinter import *
from tkinter import messagebox


#global for a reason, if the file is not found, there is no reason to continue!
WORDS = []


try:
    file = open('4to6CharWords.txt', 'r')
    #constant array of our words
    WORDS = [x for x in file]
    file.close()
except:
    print('file not found')



class hangMan:


    def __init__(self):
        self.window = Tk()
        self.window.title("Hang Man House")
        self.window.windowWidth = 850
        self.window.windowHeight = 650
        self.word = ''
        self.displayWord = ''
        self.guessedLettersText = ''
        self.setupMainWindow()
        self.houseArray = [self.houseOutline, self.houseRoof, self.garageOutline,self.garageRoof, self.windows, self.doors, self.walkways]
        self.window.bind("<Key>", self.processKeyEvent)
        
    def processKeyEvent(self, event):
        if event.char in self.word and event.char not in self.guessedLettersText:
            newDispString = ""
            for i in range(len(self.word)):
                if self.word[i] == event.char:
                    newDispString += event.char                    
                else:
                    newDispString += '*' if self.displayWord[i] == '*' else self.displayWord[i]
                    
            self.displayWord = newDispString
            self.wordLabel.configure(text = self.displayWord)
            
        else:
            if event.char not in self.guessedLettersText:
                self.guessedLettersText += event.char
                self.guessedLettersLabel.configure(text = self.guessedLettersText)

                ### call drawing functions here based on the number of letters in guessedLetters!
                self.houseArray[len(self.guessedLettersText)-1]()
                
            else:
                return
            
        if len(self.guessedLettersText) == 7:
                self.wordLabel.configure(text = self.word)
                self.wouldYouLikeToPlayAgainLoss()
        else:
            if '*' not in self.displayWord:
                self.wouldYouLikeToPlayAgainWin()
            
            
        
    def setupMainWindow(self): 
        self.canvas = Canvas(self.window, width =  self.window.windowWidth, height = self.window.windowHeight, 
            bg = "white")
        self.canvas.pack()
        self.word = random.choice(WORDS).strip()
        self.displayWord = '*' * (len(self.word))
        self.frame = Frame(self.window)
        self.frame1 = Frame(self.window)
        self.frame.pack()
        self.frame1.pack()
        self.guessAWordLabel = Label(self.frame1, text = "Guess a word: ")
        self.wordLabel = Label(self.frame1, text = self.displayWord)
        self.guessAWordLabel.grid(row = 1, column = 1)
        self.wordLabel.grid(row = 1, column = 2)
        self.missedLettersLabel = Label(self.frame1, text = "Missed Letters: ")
        self.guessedLettersLabel = Label(self.frame1, text = "")
        self.missedLettersLabel.grid(row = 2, column = 1)
        self.guessedLettersLabel.grid(row = 2, column = 2)                             
        
        
    def startOver(self):
        self.word = random.choice(WORDS).strip()
        self.displayWord = '*' * (len(self.word))
        #print(self.displayWord)
        self.wordLabel.configure(text = self.displayWord)
        self.guessedLettersText = ''
        self.guessedLettersLabel.configure(text = self.guessedLettersText)
        self.wordLabel.configure(text = self.displayWord)
        self.canvas.delete('all')




    def wouldYouLikeToPlayAgainLoss(self):
        msg = messagebox.askquestion("Better Luck Next Time!", "Restart?")
        if msg == "yes":
            self.startOver()

        if msg == "no":
            self.window.destroy()

    def wouldYouLikeToPlayAgainWin(self):
        msg = messagebox.askquestion("Congratulations!", "Restart?")
        if msg == "yes":
            self.startOver()

        if msg == "no":
            self.window.destroy()



    def houseOutline(self):
        self.canvas.create_rectangle(25,200,425,600, outline = 'black')

    def houseRoof(self):
        self.canvas.create_polygon(25,200,232.5,75,425,200, outline ='black', fill = 'white')

    def garageOutline(self):
        self.canvas.create_rectangle(425,585,825,350, outline = 'black')

    def garageRoof(self):
        self.canvas.create_polygon(825,350,425,200,425,350, outline = 'black', fill = 'white')
    
    def windows(self):
        self.canvas.create_rectangle(65,225,145,300, outline = 'black')
        self.canvas.create_line(105,225,105,300)
        self.canvas.create_line(65,262,145,262)

        self.canvas.create_rectangle(305,225,380,300, outline = 'black')
        self.canvas.create_line(342,225,342,300)
        self.canvas.create_line(305,262,380,262)

        self.canvas.create_rectangle(65,450,145,525, outline = 'black')
        self.canvas.create_line(105,450,105,525)
        self.canvas.create_line(65,487,145,487)

        self.canvas.create_rectangle(305,450,380,525, outline = 'black')
        self.canvas.create_line(342,450,342,525)
        self.canvas.create_line(305,487,380,487)

    def doors(self):
        self.canvas.create_rectangle(185,600,255,500, outline  = 'black')
        self.canvas.create_oval(245,560,250,550, outline = 'black')

        self.canvas.create_rectangle(450,585,800,450, outline = 'black')

        self.canvas.create_rectangle(470,575,565,545, outline = 'black')
        self.canvas.create_rectangle(575,575,675,545, outline = 'black')
        self.canvas.create_rectangle(685,575,780,545, outline = 'black')

        self.canvas.create_rectangle(470,535,565,507, outline = 'black')
        self.canvas.create_rectangle(575,535,675,507, outline = 'black')
        self.canvas.create_rectangle(685,535,780,507, outline = 'black')

        self.canvas.create_rectangle(470,495,565,465, outline = 'black')
        self.canvas.create_rectangle(575,495,675,465, outline = 'black')
        self.canvas.create_rectangle(685,495,780,465, outline = 'black')
        
    def walkways(self):
        self.canvas.create_line(185,600,175,650)
        self.canvas.create_line(255,600,265,650)

        self.canvas.create_line(450,585,435,650)
        self.canvas.create_line(800,585,815,650)

# if we are the main script called, run else just import into another script
if __name__ == '__main__':
    program = hangMan()
