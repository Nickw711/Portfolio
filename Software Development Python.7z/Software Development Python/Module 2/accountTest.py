'''
Nicholas Walsh
SDEV 220 Exercise 7.3 Page 237
Creates an account with the ID 1122, balance of 20000, and annual interest rate
of 4.5%. It then withdraws 2500 and deposits 3000 and then
changes the ID to 3345 and the balance to 35000.
Due February 2, 2022
'''
import account

A1 = account.Account(1122, 20000, 4.5)

A1.withdraw(2500)

A1.deposit(3000)

print(A1)

A1.changeId(3345)

A1.changeBalance(35000)

print(A1)
