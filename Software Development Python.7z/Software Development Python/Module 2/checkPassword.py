'''
Nicholas Walsh
SDEV 220 Exercise 8.3 Page 264
The program allows the user to create a password.
The program then validates the password, making sure that it contains at least
9 characters, at least 3 of which must be digits, and contains 0 special characters.
February 2, 2022
'''
count = 0
uniqueCount = 0
userPassword = input("Create a password using at least 9 characters and 3 digits: ")
if len(userPassword) < 9:
    print("Password not valid. Please use at least 9 characters.")
else:
    for character in userPassword:
        if character >= '0' and character <= '9':
            count += 1
        if character >= 'a' and character <= 'z' or character >= 'A' and character <= 'Z' or character >= '0' and character <= '9':
            continue
        else:
            uniqueCount += 1
    if uniqueCount > 0:
        print("Your Password contains a unique character and is invalid.")
    elif count >= 3:
        print("Your Password is Valid")
    else:
        print("Your password must contain at least 3 digits. Try again.")
