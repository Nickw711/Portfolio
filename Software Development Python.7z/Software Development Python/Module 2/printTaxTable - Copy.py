'''
Nicholas Walsh
SDEV 220 Exercise 6.15, page 206
The program creates a table showing your taxes based off your
status and taxable income.
February, 2, 2022
'''
def computeTax():
    taxableIncome = 50000
    counter = taxableIncome + 10000
    print("\t\t\tIncome Tax Table\n")
    print(":", "Income", ":", "Single", ":", "Married", ":", "Seperated", ":", "Head of a House", ":")
    taxableIncome -= 100
    while taxableIncome < counter:
        taxableIncome += 100
        print(":", "$" + str(taxableIncome), ":", "$" + str(taxableIncome * .25), ":", "$" + str(taxableIncome * .15), ":", "$" + str(taxableIncome * .25), ":", "$" + str(taxableIncome * .20), ":")
computeTax()
