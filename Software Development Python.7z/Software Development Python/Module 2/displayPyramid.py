"""
Nicholas Walsh
SDEV220 Exercise 5.19 Page 161
Program allows user to enter number between 1 and 15.
Then creates a pyramid with the numbers.
Due February 2, 2022
"""

userEntry = int(input("Enter any number thats between 1 and 15: "))
if userEntry < 16 and userEntry > 0:
    for x in range(1, userEntry + 1):
        for y in range(userEntry + 1 - x):
            print(" ", end = " ")
        for y in range(1, x):
            print(y, end = " ")
        for x in range(x, 0, -1):
            print(x, end = " ")
        print("\n")
    print("\n")
    for x in range(userEntry, 0, -1):
        for y in range(1, userEntry + 1 - x):
            print(" ", end = " ")
        for y in range(x, 1, -1):
            print(y, end = " ")
        for x in range(1, x + 1):
            print(x, end = " ")
        print("\n")
else:
    print("The number you entered was either too big or too small.")
