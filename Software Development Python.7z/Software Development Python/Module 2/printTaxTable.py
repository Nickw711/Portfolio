'''
Nicholas Walsh
SDEV 220 Exercise 6.15, page 206
The program creates a table showing your taxes based off your
status and taxable income.
February, 2, 2022
'''
def computeTax(status, taxableIncome):
    """
    Status
    0 = Single
    1 = Married
    2 = Seperated
    3 = Head of a House
    """
    counter = taxableIncome + 10000
    if status == 0:
        print(" Status: Single ")
        print(":", "Income", ":", "Tax", ":")
        taxableIncome -= 100
        while taxableIncome < counter:
            taxableIncome += 100
            print(":", "$" + str(taxableIncome), ":", "$" + str(taxableIncome * .25), ":")
            
    if status == 1:
        print(" Status: Married ")
        print(":", "Income", ":", "Tax", ":")
        taxableIncome -= 100
        while taxableIncome < counter:
            taxableIncome += 100
            print(":", "$" + str(taxableIncome), ":", "$" + str(taxableIncome * .15), ":")

    if status == 2:
        print(" Status: Seperated ")
        print(":", "Income", ":", "Tax", ":")
        taxableIncome -= 100
        while taxableIncome < counter:
            taxableIncome += 100
            print(":", "$" + str(taxableIncome), ":", "$" + str(taxableIncome * .25), ":")

    if status == 3:
        print(" Status: Head of a House ")
        print(":", "Income", ":", "Tax", ":")
        taxableIncome -= 100
        while taxableIncome < counter:
            taxableIncome += 100
            print(":", "$" + str(taxableIncome), ":", "$" + str(taxableIncome * .20), ":")
