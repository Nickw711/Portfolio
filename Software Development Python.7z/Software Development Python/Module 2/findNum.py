"""
Nicholas Walsh
SDEV 220 Exercise 5.13 page 160
prints all numbers, 10 on each line,
that are divisible by 7, but not 8, between 200-400.
Due Febuary 2, 2022
"""

list3 = []
list2 = []
list1 = []
count = 0

for x in range(200, 400):
    if x % 7 == 0 and x % 8 != 0:
        count += 1
        if count < 11:
            list1.append(x)
        elif count < 21:
            list2.append(x)
        else:
            list3.append(x)

print(list1)
print(list2)
print(list3)
