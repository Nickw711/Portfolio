"""
Nicholas Walsh
SDEV 220 Exercise 6.5 Page 230
This program allows you to enter 3 numbers and have them
sorted in either least to greatest order or greatest to least.
February 2, 2022
"""
def displaySorted(num1=0, num2=0, num3=0):
    numList = [num1, num2, num3]
    middle = 0
    lowNum = 0
    highNum = 0
    lowest = min(numList)
    highest = max(numList)
    for num in numList:
        if num != lowest and num != highest:
            middle = num
        elif num == lowest:
            lowNum += 1
        elif num == highest:
            highNum += 1
    if highNum > 1:
        middle = highest
    elif lowNum > 1:
        middle = lowest
    print(lowest, middle, highest)


def displayReverse(num1=0, num2=0, num3=0):
    numList = [num1, num2, num3]
    middle = 0
    lowNum = 0
    highNum = 0
    lowest = min(numList)
    highest = max(numList)
    for num in numList:
        if num != lowest and num != highest:
            middle = num
        elif num == lowest:
            lowNum += 1
        elif num == highest:
            highNum += 1
    if highNum > 1:
        middle = highest
    elif lowNum > 1:
        middle = lowest
    print(highest, middle, lowest)
