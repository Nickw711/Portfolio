'''
Nicholas Walsh
SDEV 220 Exercise 7.3 Page 237
This program creates the class account that allows the user to create an account
with the attribues; ID, balance, and annual interest rate. It then allows the user
to change or access any of the attributes with a specific function/method.
Due February 2, 2022
'''
class Account():
    def __init__(self, id=0, balance=100, annualInterestRate=0):
        self.id = id
        self.balance = balance
        self.annualInterestRate = annualInterestRate

    def changeId(self, id):
        self.id = id
        return "Your New ID is: " + str(self.id)

    def getId(self):
        return "Your ID is: " + str(self.id)

    def changeBalance(self, balance):
        self.balance = balance
        return "Your Balance is Now: $" + str(self.balance)

    def getBalance(self):
        return "Your Balance is: $" + str(self.balance)

    def changeAnnualInterestRate(self, annualInterestRate):
        self.annualInterestRate = annualInterestRate
        return "Your New Annual Interest Rate is: " + str(self.annualInterestRate) + "%"

    def getAnnualInterestRate(self):
        return "Your Annual Interest Rate is: " + str(self.annualInterestRate) + "%"

    def getMonthlyInterestRate(self):
        return "Your Monthly Interest Rate is: " + str(self.annualInterestRate / 12) + "%"

    def getMonthlyInterest(self):
        return "The Monthly Interest is: $" + str(self.balance * ((self.annualInterestRate / 100) / 12))

    def withdraw(self, balance):
        self.balance = self.balance - balance
        return "Your Balance is Now: $" + str(self.balance)

    def deposit(self, balance):
        self.balance += balance
        return "Your Balance is Now: $" + str(self.balance)

    def __str__(self):
        return "ID: " + str(self.id) + "\nBalance: $" + str(self.balance) + "\nAnnual Interest Rate: " + str(self.annualInterestRate) + "%"\
    + "\nMonthly Interest Rate: " + str(self.annualInterestRate / 12) + "%" + "\nMonthly Interest: $" + str(self.balance * ((self.annualInterestRate / 100) / 12))
