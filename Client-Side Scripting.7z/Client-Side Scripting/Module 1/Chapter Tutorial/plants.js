/* Javascript 6th Edition
	Chapter 1
	Chapter case
	
	Tinley Xeriscapes
	Author: Nicholas Walsh
	Date: 10/22/2021
	
	Filename: plants.js
*/
		//define variables containing img src values
		var blanket = "images/blanket.jpg";
		var bluestem = "images/bluestem.jpg";
		var rugosa = "images/rugosa.jpg";