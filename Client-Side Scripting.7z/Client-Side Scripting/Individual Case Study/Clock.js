// Function that is called by an on click function in the HTML form.
function findDate() {
	// finds the time for that given moment
	var startTime = new Date();
	// finds the time for the date chosen on the form
	var endTime = new Date(document.getElementById("date1").value)
	// finds the difference between the times
	var timeDiff = (startTime - endTime);
	// calculates the time into days, hours, minutes, and seconds
	timeDiff /= 1000;
	var seconds = Math.round(timeDiff % 60);
	timeDiff = Math.floor(timeDiff / 60);
	var minutes = Math.round(timeDiff % 60);
	timeDiff = Math.floor(timeDiff / 60);
	var hours = Math.round(timeDiff % 24);
	timeDiff = Math.floor(timeDiff / 24);
	var days = timeDiff;
	// outputs the amount of time that has past since the date chosen in the form
	document.getElementById("beforeTime").innerHTML = "";
	document.getElementById("beforeTime").innerHTML = "The amount of time that has past since " + endTime + ":";
	document.getElementById("showTime").innerHTML = "";
	document.getElementById("showTime").innerHTML += days + ":" + hours + ":" + minutes + ":" + seconds;
	refresh();
}
//Continueously updates the time, after the date has been chosen.
function refresh() {
	var refresh = 1000;
	mytime=setTimeout('findDate()', refresh);
}