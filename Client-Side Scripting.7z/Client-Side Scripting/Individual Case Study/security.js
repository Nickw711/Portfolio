// Creating a script element that contains the URL for the API.
function loadDirections(string) {
	if (typeof google !== 'object') {
	   var script = document.createElement("script");
	   script.src = "https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=true&callback=geoTest";
	   document.body.appendChild(script);
	}
}
// Test to see if the user allowed access to their location.
function geoTest() {
	waitForUser = setTimeout(fail, 10000);
	if (navigator.geolocation) {
		navigator.geolocation.getCurrentPosition(createDirections, fail, {timeout: 10000});
	} else {
		fail();
	}
}
// Creating the map using the users position in longitude and latitude.
function createDirections(position) {
	// clears the timeout if the user allows access to their location
	clearTimeout(waitForUser);
	var currPosLat = position.coords.latitude;
	var currPosLng = position.coords.longitude;
	var altitude = position.coords.altitude;
	// outputs longitude, latitude, and altitude onto the webpage
	document.getElementById("lngLat").innerHTML = "Longitude: " + currPosLng + " Latitude: " + currPosLat + " Altitude: " + altitude;
	var mapOptions = {
		center: new google.maps.LatLng(currPosLat, currPosLng), zoom: 12
	};
	var map = new google.maps.Map(document.getElementById("map"), mapOptions);
}
// Function that tells the user when unable to access their location.
function fail() {
	document.getElementById("map").innerHTML = "Unable to access your current location.";
}
// Function that creates an event listener for the button.
function setUpPage() {
	document.querySelector("button").addEventListener("click", loadDirections, false);
}
// Window event listener that activates the button if it's pressed.
window.addEventListener("load", setUpPage, false);