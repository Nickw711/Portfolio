/*    JavaScript 6th Edition
 *    Chapter 2
 *    Chapter case

 *    Calculations for my website

 *    Author: Nicholas Walsh
 *    Date:   11/3/2021

 *    Filename: Calculation.js
 */
 var totalEstimate = 0
//creates function for the two numbers entered to by multiplied
 function Calculate() {
	 var firstN = document.getElementById("firstNumber");
	 var secondN = document.getElementById("secondNumber");
	 totalEstimate = firstN.value * secondN.value;
	 document.getElementById("estimate").innerHTML = totalEstimate;
 }
 //creates event listeners
 function createEventListeners() {
	document.getElementById("firstNumber").
		addEventListener("change", Calculate, false);
	document.getElementById("secondNumber").
		addEventListener("change", Calculate, false);
 }
 //creates the image change function
 function changeImage() {
	 var image = document.getElementById('image');
	 if (totalEstimate > 0) {
		 image.src = 'positive.jfif';
	 } else if (totalEstimate < 0) {
		 image.src = 'negative.png';
		} else {
			image.src = 'zero.jfif';
		}
 }
 //adds all functions to a start up function
 function startUp() {
	 Calculate();
	 createEventListeners();
 }
 //initializes the startup fuction on load
if (window.addEventListener) {
	window.addEventListener("load", startUp, false);
} else if (window.attachEvent) {
	window.attachEvent("onload", startUp);
}