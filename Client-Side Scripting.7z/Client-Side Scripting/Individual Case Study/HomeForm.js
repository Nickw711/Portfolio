// Prevents numbers and symbols from being entered into the name sections on the form.
function validateName() {
	return (event.charCode > 64 && 
	event.charCode < 91) || (event.charCode > 96 && event.charCode < 123)
}
// Prevents letters and symbols from being entered into the phone number elemnt on the form.
function validateNumber(evt) {
	var ch = String.fromCharCode(evt.which);
	if (!(/[0-9]/.test(ch))){
		evt.preventDefault();
	}
}
// Alerts the user if the form element is blank by changing the color to red.
function validateFirstName() {
	var x = document.getElementById("firstName").value;
	if (x == "") {
		document.getElementById("firstName").style.background = "rgb(255,233,233)";
	}
}
// Alerts the user if the form element is blank by changing the color to red.
function validateLastName() {
	var xx = document.getElementById("lastName").value;
	if (xx == "") {
		document.getElementById("lastName").style.background = "rgb(255,233,233)";
	}
}
// Alerts the user if the form element is blank by changing the color to red.
function validateEmail() {
	var y = document.getElementById("emailAddress").value;
	if (y == "") {
		document.getElementById("emailAddress").style.background = "rgb(255,233,233)";
	}
}
// Alerts the user if the form element is blank by changing the color to red.
function validateNum() {
	var z = document.getElementById("phoneNumber").value;
	if (z == "") {
		document.getElementById("phoneNumber").style.background = "rgb(255,233,233)";
	}
}
// Keeps the user from submitting the form without checking any of the checkboxes.
function validateSports() {
	var checked = 0;
	var chks = document.getElementsByName("chkbox");
	for (var i = 0; i < chks.length; i++) {
		if (chks[i].checked) {
			checked++
		}
	}
	if (checked < 1) {
		alert("Please check one of the answers in the sports section");
		event.preventDefault();
	}
}
// Declares a global variable that contains a list.
var information = {
  letters: []
}
// Outputs the checked values in the checkbox onto the webpage.
function letter(ev) {
  if (ev.target.checked) {
    information.letters.push(ev.target.value);
  } else {
    var index = information.letters.indexOf(ev.target.value); 
    if (index !== -1){
      information.letters.splice(index, 1);
    }
  }
  var showAbc = information.letters.join(", ");
  document.getElementById("displaylet").innerHTML = showAbc;
}
// Starts the select element, for the gender, at -1 so nothing is selected.
function removeSelectDefaults() {
	var emptyBoxes = document.getElementsByTagName("select");
	for (var i = 0; i < emptyBoxes.length; i++) {
		emptyBoxes[i].selectedIndex = -1;
	}
}
// Alerts the user and changes the gender border color to red if a gender isn't selected.
function validateGender() {
	var selectElements = document.querySelectorAll("#gender, select");
	var elementCount = selectElements.length;
	var currentElement;
	for (var i = 0; i < elementCount; i++) {
			currentElement = selectElements[i];
			if (currentElement.selectedIndex === -1) {
				currentElement.style.border = "1px solid red";
				event.preventDefault();
				alert("Please enter your gender.")
			}
	}
}
// Function that calls all the validate form functions.
function validateForm() {
	validateFirstName();
	validateLastName();
	validateEmail();
	validateNum();
	validateSports();
	validateGender();
}
// Creates two event listeners.
function createEventListeners() {
	// event listener to call the validateForm function when the submit button is clicked
	var form = document.getElementsByTagName("form")[0];
	if (form.addEventListener) {
		form.addEventListener("submit", validateForm, false);
	} else if (form.attachEvent) {
		form.attachEvent("onsubmit", validateForm);
	}
	// event listener to output the checked checkboxes
	var box = document.getElementsByName("chkbox");
	if (box[0].addEventListener) {
		for (var i = 0; i < box.length; i++) {
			box[i].addEventListener("change", letter, false);
		}
	} else if (box[0].attachEvent) {
		for (var i = 0; i < box.length; i++) {
			box[i].attachEvent("onchange", letter);
		}
	}
}
// Function to call other functions on load.
function setUpPage() {
	removeSelectDefaults();
	createEventListeners();
}
// Calls the function setUpPage on load.
if (window.addEventListener) {
	window.addEventListener("load", setUpPage, false);
} else if (window.attachEvent) {
	window.attachEvent("onload", setUpPage);
}