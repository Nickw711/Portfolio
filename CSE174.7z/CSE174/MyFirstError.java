public class MyFirstError{

  public static void main(String [] args) {
    System.out.println("Hello Good Fellas");

    System.out.println("   |||||    ");
    System.out.println(" .'     '.  ");
    System.out.println("|  O   O  | ");
    System.out.println("|    *    | ");
    System.out.println("|    _    | ");
    System.out.println(" '.     .'  ");
    System.out.println("   -...-    ");

    System.out.println("This is Tin Tin saying Hi!!!");

  }
}
