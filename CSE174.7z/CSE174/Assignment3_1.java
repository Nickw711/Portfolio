/**
 * Author: Nicholas Walsh
 * Date: 09/23/2022
 * Description: Lets the user input their first name and last name. Then it lets the user input the length and height for the surface area 
 * as well as the number of walls that needs to be painted. The program then calculates the discount based on how many total square meters
 * are going to be painted. Finally the program calculates the price of the painting and prints out the total surface area, the painting cost,
 * the discount on the cost, the customers initials, and the customers trasaction ID.
**/
import java.util.Scanner;
import java.lang.Math;

public class Assignment3_1{
  
  public static void main(String [] args) {
    
    Scanner input = new Scanner(System.in);
    
    System.out.print("Please enter your first name: ");
    String fName = input.next();
    System.out.print("Please enter your last name: ");
    String lName = input.next();
    
    
    System.out.print("Please enter the width of you walls in meters: ");
    double width = input.nextDouble();
    System.out.print("Please enter the height of your walls in meters: ");
    double height = input.nextDouble();
    
    System.out.print("Please enter the number of walls that will be painted: ");
    double walls = input.nextDouble();
    
    double surfaceArea = (width * height);
    double totalSurfaceArea = (surfaceArea * walls);
    
    double discount = 0;
    String discountPercent = "None";
    
    if (totalSurfaceArea < 100) {
      discount = .01;
      discountPercent = "1%";
    }
    else if (totalSurfaceArea < 1000) {
      discount = .05;
      discountPercent = "5%";
    }
    else if (totalSurfaceArea < 5000) {
      discount = .07;
      discountPercent = "7%";
    }
    else if (totalSurfaceArea > 5000) {
      discount = .10;
      discountPercent = "10%";
    }
    else {
      System.out.print("There was a problem calculating your discount price please restart the program.");
    }
    
    double paintingCost = (discount * (totalSurfaceArea * 20));
    paintingCost = (totalSurfaceArea * 20 - paintingCost);
    
    System.out.printf("Surface Area to be Painted: %.2f", totalSurfaceArea);
    System.out.printf("\nCost of Painting: $%.2f", paintingCost);
    System.out.print("\nDiscount on Cost: " + discountPercent);
    System.out.print("\nYour Initials: " + fName.substring(0,1) + lName.substring(0,1));
    System.out.print("\nYour Transaction ID: " + fName + "-007-AWESOME-CSE174-" + lName);
                     
    }
}