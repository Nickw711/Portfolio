import java.util.Scanner;
public class test 
{
public static void main(String[] args)
{
   double count = 15.0;
if (count / 3.0) 
{
   System.out.println("The value of count is ");
}
}
}


