/**
 * Author: Nicholas Walsh
 * Date: 09/30/2022
 * Description: Allows the user enter two integers. then the program calculates the sum of all the odd numbers within
 * both integers. The program then calculates the square of all even numbers added together between 1 and 100. After
 * that, the program allows the user to enter more numbers (however many they want to enter), calculates the average 
 * of all the numbers and the smallest and largest number. Finally, the program asks the user to enter their name,
 * returning their name reversed.
**/
import java.util.Scanner;
import java.lang.Math;

public class Lab4_1{
  
  public static void main(String [] args) {
    
    Scanner input = new Scanner(System.in);
    
    
    int oddSum = 0;
    int evenSquared = 0;
    for (int i = 1; i <=100; i++) {
      if (i % 2 == 0) {
        evenSquared = evenSquared + (i * i);
      }
    }
    String sentinel = "3";
    while (!sentinel.equals("Q"))
    {
      oddSum = 0;
      System.out.println("Enter your first number");
      int i1 = input.nextInt();
      System.out.println("Enter your second number");
      int i2 = input.nextInt();
      try
      {
        double sentinelValue = Double.parseDouble(sentinel);
        for (int i = i1; i <= i2; i++)
        {
          if (i % 2 == 1)
          {
            oddSum = oddSum + i; 
          }
        }
        System.out.println("The sum of all odd numbers between " + i1 + " and " + i2 + ": " + oddSum);
        System.out.println("The sum of squares between 1 and 100: " + evenSquared);
      }
      catch(NumberFormatException e)
      {
        System.out.println("You did not enter a number.");
      }
      System.out.println("Enter a number to continue or \"Q\" to quit: ");
      sentinel = input.next().toUpperCase();
    }
    
    
    //Average, smallest, and largest numbers code
    double strNumbers = 0;
    double average = 0;
    int count = 0;
    double smallestNumber = 9999999;
    double largestNumber = 0;
    System.out.println("Enter some numbers or -1 to finish: ");
    while (strNumbers != -1)
    {
      strNumbers = input.nextDouble();
      if (strNumbers != -1)
      {
        average = average + strNumbers;
        count++;
        if (strNumbers < smallestNumber)
        {
          smallestNumber = strNumbers;
        }
        if (strNumbers > largestNumber)
        {
          largestNumber = strNumbers;
        }
      }
    }
    if (count > 0)
    {
      average = average / count;
      System.out.println("The average of the entered values is: " + average);
      System.out.println("The smallest number is: " + smallestNumber);
      System.out.println("The largest number is: " + largestNumber);
    }
    else
    {
      System.out.println("No numbers entered");
    }
    
    
    //Reverse Name Code
    System.out.println("Please enter your first name: ");
    String fName = input.next();
    char ch;
    String reversedName = "";
    for (int i=0; i<fName.length(); i++)
    {
      ch = fName.charAt(i);
      reversedName = ch + reversedName;
    }
   System.out.println("Your name when reversed is: " + reversedName);
  
   input.close();
  }
}