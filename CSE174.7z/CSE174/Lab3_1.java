/**
 * Author: Nicholas Walsh
 * Date: 09/14/2022
 * Description: Rock, Paper, Scissors two player game set up with inputs and comparison operators.
**/
import java.util.Scanner;

public class Lab3_1{
  
  public static void main(String [] args) {
  
    Scanner input = new Scanner(System.in);
    
    System.out.print("Player1 choose your hand(rock, paper, or scissors): ");
    String player1 = input.next().toLowerCase();
    System.out.print("Player2 choose your hand(rock, paper, or scissors): ");
    String player2 = input.next().toLowerCase();
    
    if (player1.equals(player2)) {
      System.out.print("There has been a tie!");
    }
    else if (player1.equals("rock") & player2.equals("scissors")) {
      System.out.print("Player1 Wins!");
    }
    else if (player1.equals("paper") & player2.equals("rock")) {
      System.out.print("Player1 Wins!");
    }
    else if (player1.equals("scissors") & player2.equals("paper")) {
      System.out.print("Player1 Wins!");
    }
    else if (player2.equals("rock") & player1.equals("scissors")) {
      System.out.print("Player2 Wins!");
    }
    else if (player2.equals("paper") & player1.equals("rock")) {
      System.out.print("Player2 Wins!");
    }
    else if (player2.equals("scissors") & player1.equals("paper")) {
      System.out.print("Player2 Wins!");
    }
    else {
      System.out.println("There has been an error with one of the player's inputs.");
      System.out.print("Please restart and try again!");
    }
  }
}