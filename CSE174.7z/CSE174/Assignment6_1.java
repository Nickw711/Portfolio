/**
 * Author: Nicholas Walsh
 * Date: 11/3/2022
 * Description: This program asks the user for an input of a price they'd wish to pay for a movie. If the price is
 * appropriate, the program checks to see if there is an available seat for that price. If so, you are returned with
 * a seat number. If not, you'll recieve a message that there are no available seats for that price.
**/
import java.util.Scanner;
import java.lang.Math;

public class Assignment6_1{
  
  public static void main(String [] args) {
    
    //Declaring Lists and Variables
    int[][] seatPrices = {
      {10, 10, 10, 10, 10, 10, 10, 10, 10, 10},
      {10, 10, 10, 10, 10, 10, 10, 10, 10, 10},
      {10, 10, 10, 10, 10, 10, 10, 10, 10, 10},
      {10, 10, 20, 20, 20, 20, 20, 20, 10, 10},
      {10, 10, 20, 20, 20, 20, 20, 20, 10, 10},
      {10, 10, 20, 20, 20, 20, 20, 20, 10, 10},
      {20, 20, 30, 30, 40, 40, 30, 30, 20, 20},
      {20, 40, 50, 50, 50, 50, 50, 50, 40, 20},
      {80, 50, 50, 80, 80, 80, 80, 50, 50, 30}
    };
    int[][] seatNumbers = {
      {1, 2, 3, 4, 5, 6, 7, 8, 9, 10},
      {11, 12, 13, 14, 15, 16, 17, 18, 19, 20},
      {21, 22, 23, 24, 25, 26, 27, 28, 29, 30},
      {31, 32, 33, 34, 35, 36, 37, 38, 39, 40},
      {41, 42, 43, 44, 45, 46, 47, 48, 49, 50},
      {51, 52, 53, 54, 55, 56, 57, 58, 59, 60},
      {61, 62, 63, 64, 65, 66, 67, 68, 69, 70},
      {71, 72, 73, 74, 75, 76, 77, 78, 79, 80},
      {81, 82, 83, 84, 85, 86, 87, 88, 89, 90}
    };
    Scanner input = new Scanner(System.in);
    String userInput = "";
    int[] priceList = {10, 20, 30, 40, 50, 80};
    boolean validPrice = false;
    
    
    //While loop and validation for user input
    while (!userInput.equals("Q")) 
    {
      System.out.println("Input a price or type \"Q\" to quit: ");
      userInput = input.next().toUpperCase();
      if (!userInput.equals("Q"))
      {
        int priceInput = Integer.parseInt(userInput);
        for (int x = 0; x < 6; x++)
        {
          if (priceInput == priceList[x])
          {
            validPrice = true;
          }
        }
        if (validPrice)
        {
          System.out.println("\nChecking for the availability...");
          seatAvailablility(priceInput, seatPrices, seatNumbers);
        }
        else
        {
          System.out.println("\nPlease enter a valid price. Valid prices are $10, $20, $30, $40, $50, and $80");
        }
      }
    }
  }
  
  /*
   * Searches for an available seat at the user entered price.
   * @int userPrice - Price input by user from main method.
   * @int[][]seatPrices - 2d list of all the prices of each seat.
   * @int[][]seatNumbers - 2d list of all the seat numbers.
   * @return - Returns the seat number available, or no availablility if so.
   */
  static void seatAvailablility(int userPrice, int[][]seatPrices, int[][]seatNumbers) {
    boolean seatBought = false;
    
    outerloop:
    for (int x = 0; x < 9; x++)
    {
      for (int y = 0; y < 10; y++)
      {
        if (userPrice == seatPrices[x][y])
        {
          seatPrices[x][y] = 0;
          seatBought = true;
          System.out.println("Your seat is confirmed! Your seat number is " + seatNumbers[x][y] + ". Enjoy your movie!\n");
          break outerloop;
        }
        else
        {
          continue;
        }
     }
    }
    seatConfirmation(seatBought);
  }
  
  /*
   * Checks and returns a message to the user if the seat is unavailable.
   * @boolean seatBought - determines whether the seat has been bought already or not.
   * @return - returns no availablity to the user if there is no seat available.
   */
  static void seatConfirmation(boolean seatBought) {
    if (seatBought)
    {
      return;
    }
    else
    {
      System.out.println("Sorry, no seat available at this price.\n");
    }
  }
}