/**
 * Author: Nicholas Walsh
 * Date: 09/10/2022
 * Description: Lets the user input their first name, last name, and the length, width, and height for the surface area to be painted.
 * The program then creates the users customer and transaction id as well as, calculates the surface area of the painting
 * and price the customer will have to pay. The program also calculates how many dollars, quarters, dimes, nickels, and pennys for that
 * payment.
**/
import java.util.Scanner;
import java.lang.Math;

public class Assignment2_1{
  
  public static void main(String [] args) {
    
    Scanner input = new Scanner(System.in);
    
    System.out.print("Please enter your first name: ");
    String fName = input.next();
    System.out.print("Please enter your last name: ");
    String lName = input.next();
    System.out.print("Please enter the length in meters: ");
    double length = input.nextDouble();
    System.out.print("Please enter the width in meters: ");
    double width = input.nextDouble();
    System.out.print("Please enter the height in meters: ");
    double height = input.nextDouble();
    
    double surfaceArea = 2 * ((length * width) + (length * height) + (width * height));
    String customerID = fName.substring(0,2) + lName.substring(lName.length()-2);
    String transactionID = fName.substring(0,1) + lName.substring(0,1) + "-" + "007" + "-" + lName + fName.substring(0,1);
    double paintingCost = (surfaceArea * 20) + ((surfaceArea * 20) * .03);
    
    System.out.println("Valued Customer: " + fName + " " + lName);
    System.out.printf("Surface Area to be Painted: %.2f", surfaceArea);
    System.out.printf("\nCost of Painting: %.2f", paintingCost);
    
    int dollars = 0;
    int quarters = 0;
    int dimes = 0;
    int nickels = 0;
    int pennys = 0;
    while (paintingCost > 1) {
      paintingCost = paintingCost - 1;
      dollars++;
    }
    while (paintingCost > .25) {
      paintingCost = paintingCost - .25;
      quarters++;
    }
    while (paintingCost > .10) {
      paintingCost = paintingCost - .10;
      dimes++;
    }
    while (paintingCost > .05) {
      paintingCost = paintingCost - .05;
      nickels++;
    }    
    while (paintingCost > .01) {
        paintingCost = paintingCost - .01;
        pennys++;
    }
    
    System.out.println("\nDollars: " + dollars);
    System.out.println("Quarters: " + quarters);
    System.out.println("Dimes: " + dimes);
    System.out.println("Nickels: " + nickels);
    System.out.println("Pennys: " + pennys);
    
    System.out.println("Customer ID: " + customerID);
    System.out.println("Transaction ID: " + transactionID);
  }
}