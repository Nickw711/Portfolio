/**
 * Author: Nicholas Walsh
 * Date: 10/16/2022
 * Description: Once ran, the program random numbers between 3 and 30 until one that is odd and greater than 7 is created.
 * This number is then passed to the printHouse method where a pyramid is printed spanning half the random number and a
 * square is printed for the other half of the number, making a house design.
**/
import java.util.Scanner;
import java.lang.Math;

public class Lab5_1{
  
  public static void main(String [] args) {
    
    
   //Declaring Variables
    int randomNumber = 0;
    
    //Finding Random Number
    do
    {
      randomNumber = 3 + (int) (Math.random()*27);
    }
    while (randomNumber % 2 != 1 || randomNumber < 7);
    
    //Validating Number
    if (randomNumber > 6 && randomNumber % 2 == 1)
    {
      System.out.println("Your Random Number: " + randomNumber);
      printHouse(randomNumber);
    }
    else
    {
      System.out.println("Error, Random Number Wasn't Validated Correctly");
    }
    
  }
  
  static void printHouse(int n) {
    //Declaring Counter Variables
    int i, j, k;
    
    //for loop for the pyramid
    for (i=0; i<=n/2-1; i++)
    {
      for(j=0; j<n-i; j++)
      {
        System.out.print(" ");
      }
      for(k=0; k<=i; k++)
      {
        System.out.print("* ");
      }
      System.out.println();
    }
    
    //for loop for the square
    double base = n/2 + .5;
    for (i=0; i<=base; i++)
    {
      for(j=0; j<=base; j++)
      {
        System.out.print(" ");
      }
      for(k=0; k<=base; k++)
      {
        System.out.print("* ");
      }
      System.out.print("\n");
    }
  }
}