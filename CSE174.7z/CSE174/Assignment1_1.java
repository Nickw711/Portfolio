public class Assignment1_1{

  public static void main(String [] args) {
    System.out.println("Name   |   Birthday   |   Hometown");
    System.out.println("Nick   |   07/11/02   |   Brookville, IN");
    System.out.println("Tanner |   11/01/00   |   Brookville, IN");
    System.out.println("Jared  |   03/10/02   |   Brookville, IN");
    System.out.println("Walter |   08/28/01   |   Brookville, IN");
    System.out.println("Evan   |   10/23/01   |   Brookville, IN");

  }
}
