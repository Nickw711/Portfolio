/**
 * Author: Nicholas Walsh
 * Date: 10/5/2022
 * Description: Generates 10 random numbers between 10 and 100. Assigns the first odd number encounted to "oddNumber"
 * variable. Prints statements and the 10 generated numbers. Nested loop goes through all the numbers leading up to the
 * oddNumber variable, looking for prime numbers. If the number is prime the program prints the number into the console.
**/
import java.util.Scanner;
import java.lang.Math;

public class Exam1{
  
  public static void main(String [] args) {
    Scanner input = new Scanner(System.in);
    
    //Declaring Variables
    int randomNumber = 0;
    String numberOutput = "";
    int oddNumber = 0;
    
    
    //Generates 10 random numbers between 10 and 100
    for (int i = 1; i <= 10; i++)
    {
      randomNumber = 10 + (int) (Math.random()*90);
      numberOutput = numberOutput + " " + randomNumber;
      if (randomNumber % 2 != 0)
      {
        if (oddNumber == 0)
        {
          oddNumber = randomNumber;
        }
      }
    }
    
    
    //Print statements
    System.out.println("Your Ten Randomly Generated Numbers:\n" + numberOutput + "\n");
    System.out.println("The First Odd Number Encountered: " + oddNumber + "\n");
    System.out.println("All Prime Numbers Leading Up To " + oddNumber + ":");
    
    
    //Finds and prints prime numbers to the console
    for (int counter = 2; counter <= oddNumber; counter++)
    {
      boolean primeNumber = true;
      for (int factor = 2; factor < counter; factor++)
      {
        if (counter % factor == 0)
        {
          primeNumber = false;
        }
      }
      if (primeNumber)
      {
        System.out.println(counter);
      }
    }
    input.close();
  }
}