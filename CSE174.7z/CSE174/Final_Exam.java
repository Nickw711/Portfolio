/**
 * Author: Nicholas Walsh
 * Date: 12/9/2022
 * Description: This program allows the user to input a file of their choice. Each line in this file is then processed
 * and reversed. Each reversed line is written back into the same user inputted file.
 **/

import java.util.*;
import java.lang.*;
import java.io.*;

public class Final_Exam{
  
  public static void main(String [] args) {
    //call readFile method
    readFile();
  }
  
  
  
   /*
   * Allows user to input a specific file of their choice. Goes through each line of the file, adding all lines to an
   * array list. Calls the reverseFile method using the file and array list parameters.
   * @return - returns all contents of the file to an array list.
   */
  static void readFile() {
    //declaring variables
    Scanner in = new Scanner(System.in);
    String userInput = "";
    ArrayList<String> lines = new ArrayList<String>();
    
    try {
      //setting up file and scanner input to file
        System.out.println("Enter the file you wish to reverse (\"example.txt\"): ");
        userInput = in.next();
        File file = new File(userInput);
        Scanner input = new Scanner(file);
        
        //while loop to add each line of the file to an array list
        while(input.hasNextLine()) {
          lines.add(input.nextLine());
        }
        
        input.close();
      } catch (FileNotFoundException e) {
        System.out.println("An error occurred in the readFile try-catch block.");
        e.printStackTrace();
    }
      reverseFile(userInput, lines);
  }
  
  
  
  /*
   * Takes the file and array list from the readFile method. Uses the array list to write the lines in reverse. Each
   * reversed line is added to a new array list.
   * @fileInput - parameter for the file input by the user.
   * @lines - parameter for the array list containing all the lines of a file.
   * @return - returns the file and array list containing all reversed lines of the file to the writeFile method.
   */
   static void reverseFile(String fileInput, ArrayList<String> lines) {
     ArrayList<String> reversedLines = new ArrayList<String>();
     //reverses each line of the file
     try {
       for(int i=0; i <= lines.size()-1; i++) {
         String line = lines.get(i);
         String newLine = "";
         for (int j = line.length() -1; j >=0; j--) {
           char c = line.charAt(j);
           newLine = newLine + c;
         }
         //adds reversed line to the new array list
          reversedLines.add(newLine);
       }
     }catch(Exception e) {
       System.out.println("An error occurred in the reverseFile try-catch block.");
        e.printStackTrace();
     }
     writeFile(fileInput, reversedLines);
   }
  
   
   
   /*
   * Takes the file and array list from the reverseFile method. Uses the array list to write the reversed lines back into
   * the user inputted file.
   * @fileInput - parameter for the file input by the user.
   * @lines - parameter for the array list containing all reversed lines of a file.
   * @return - returns all reversed lines of a file back into the same file.
   */
  static void writeFile(String fileInput, ArrayList<String> lines) {
    try {
      //setting up file 
        File file = new File(fileInput);
        Scanner input = new Scanner(file);
        PrintWriter output = new PrintWriter(file);
        
        //prints reversed text back to the same file
        for (int i=0; i <= lines.size()-1; i++) {
          output.println(lines.get(i));
        }
        
        input.close();
        output.close();
      } catch (IOException e) {
        System.out.println("An error occurred in the writeFile try-catch block.");
        e.printStackTrace();
    }
  }
}