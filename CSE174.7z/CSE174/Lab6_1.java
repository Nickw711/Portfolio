/**
 * Author: Nicholas Walsh
 * Date: 10/26/2022
 * Description: This program asks the user for an integer input for the amount of random numbers to be generated in an
 * array. Prints the array. Calculates the sum of even indexes, the average of odd indexes, and prints them. Asks the
 * user for input on amount of rotations the array goes through. Prints the newly rotated array.
**/
import java.util.Scanner;
import java.lang.Math;

public class Lab6_1{
  
  public static void main(String [] args) {
    
    //Declaring Variables
    Scanner input = new Scanner(System.in);
    int number_of_elements;
    int sum_of_even_indexes = 0;
    double average_of_odd_indexes = 0;
    int number_of_odds = 0;
    int rotationNumber = 0;
    
    //Input Validaton
    do
    {
    System.out.println("Please Enter The Number of Elements in Your List(7 or more): ");
    number_of_elements = input.nextInt();
    }while (number_of_elements < 7);
    
    //Filling indexes with randomly generated numbers
    //Suming even indexes and odd indexes
    int[] numberList = new int[number_of_elements];
    for (int i=0; i < number_of_elements; i++)
    {
     numberList[i] = 1 + (int) (Math.random()*99);
    }
    System.out.print("The randomly generated integers in the array are: ");
    for (int j=0; j < number_of_elements; j++)
    {
      System.out.print(numberList[j] + " ");
      if (j % 2 == 0)
      {
        sum_of_even_indexes = sum_of_even_indexes + numberList[j];
      }
      else
      {
        average_of_odd_indexes = average_of_odd_indexes + numberList[j];
        number_of_odds++;
      }
    }
    
    //Averaging summed odds
    average_of_odd_indexes = average_of_odd_indexes / number_of_odds;
    
    //Print Statements
    System.out.println("\nSum of numbers at even indexes = " + sum_of_even_indexes);
    System.out.printf("Average of numbers at odd indexes = %.2f", average_of_odd_indexes);
    
    //Rotation user input with input validation
    System.out.println("\nEnter Rotation Count: ");
    do
    {
      rotationNumber = input.nextInt();
    }while (rotationNumber < 0);
    
    //Calling rotateArray method
    rotateArray(numberList, rotationNumber);
  }
  
  
    /*
   * Rotates an array to the left n amount of times
   * @int[] x - passed array to be rotated
   * @int n - passed integer for amount of rotations
   * @return - rotated array
   */
  static void rotateArray(int[] x, int n) {
    for (int i=0; i < n; i++)
    {
      int temp = x[0];
      int j;
      for (j=0; j < x.length - 1; j++)
      {
        x[j] = x[j +1];
      }
      x[j] = temp;
    }
    System.out.println("After " + n + " Rotations, Your array looks like: ");
    for (int k=0; k < x.length; k++)
    {
      System.out.print(x[k] + " ");
    }
  }
}