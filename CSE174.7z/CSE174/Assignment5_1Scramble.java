/**
 * Author: Nicholas Walsh
 * Date: 10/21/2022
 * Description: This program asks the user for an input of a word with the length of 6 or more letters. This word is
 * then passed to the method scramble(). The scramble method takes the word, scrambles everything in between,
 * leaving the first and last letters untouched. Finally, returns the scrambled word to the user.
**/
import java.util.Scanner;
import java.lang.Math;

public class Assignment5_1Scramble{
  
  public static void main(String [] args) {
    
    Scanner input = new Scanner(System.in);
    
   //Declaring Variables
    String word = "";
    
    //Do loop for the user input of a 6 or more lettered word
    do
    {
      System.out.println("Please Enter a Word That Has 6 or More Words: ");
      word = input.next();
    }
    while (word.length() < 6);
    scramble(word);
  }
  
  /*
   * Scramble a word input by the user keep the first and last letter the same, mixing up the letters in between.
   * @String word - word to be scrambled, for this program, word that had been input by the user.
   * @return - scrambled word.
   */
  static void scramble(String word) {
    
    //Declaring Variables
    String numList = "0";
    boolean usedDigit = false;
    boolean done = false;
    
    //prints first letter
    System.out.print(word.charAt(0));
    
    //While loop that scrambles the letters in between the first and last letter
    while (!done)
    {
      for (int i=1; i<word.length()-1; i++)
      {
        int randomNum = 1 + (int) (Math.random()*word.length()-2);
        for (int j=0; j<numList.length(); j++)
        {
          int current = Character.getNumericValue(numList.charAt(j));
          if (randomNum == current)
          {
            usedDigit = true;
          }
          else
          {
            continue;
          }
        }
        if (usedDigit)
        {
          i--;
          usedDigit = false;
        }
        else
        {
          numList += randomNum;
          System.out.print(word.charAt(randomNum));
        }
      }
      done = true;
    }
    //Prints last letter
    System.out.print(word.charAt(word.length()-1));
  }
}