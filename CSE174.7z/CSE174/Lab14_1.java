/**
 * Author: Nicholas Walsh
 * Date: 11/18/2022
 * Description: In this program the user chooses a number 1-4 to pick either a linear search, binary search, bubble sort,
 * or insertion sort. Once selected the user will be prompted to enter a file to input and a file for the data to
 * be outputted. The user then may go check the output file to see the data from the search or sort.
**/
import java.util.*;
import java.lang.Math;
import java.io.*;

public class Lab14_1{
  
  public static void main(String [] args) {
    //declaring variables
    Scanner input = new Scanner(System.in);
    int userInput = 0;
    //user input
    System.out.println("Choose a search or sort by entering a number 1-4: ");
    System.out.println("1. Linear Search \n2. Binary Search \n3. Bubble Sort \n4. Insetion Sort");
    try {
      userInput = input.nextInt();
      if (userInput == 1) {
        System.out.println("You Selected Linear Search. Please wait...");
        linearSearch();
      }
      else if (userInput == 2) {
        System.out.println("You Selected Binary Search. Please wait...");
        binarySearch();
      }
      else if (userInput ==3) {
        System.out.println("You Selected Bubble Sort. Please wait...");
        bubbleSort();
      }
      else if (userInput == 4) {
        System.out.println("You Selected Insertion Sort. Please wait...");
        insertionSort();
      }
    }
    catch(InputMismatchException e) {
      System.out.println("You did not enter a number.");
    }
  }
  
   /*
   * Conducts a linear search upon the user-inputted file and outputs the details to the user-inputted output file.
   * @return - returns details to the user-inputted output file.
   */
  static void linearSearch() {
    //declare variables
    Scanner input = new Scanner(System.in);
    long time_taken_linear = 0;
    int count_linear = 0;
    
    //Get file input from user
    System.out.println("Enter the name of the file you wish to read: ");
    String str = input.next();
    System.out.println("Enter the name of the file you wish to output to: ");
    String outputStr = input.next();
    
    //Get search query
    System.out.println("Enter the search query");
    Scanner in = new Scanner(System.in);
    String search = in.nextLine();
    try{
      //Read the file
      File file = new File(str);
      Scanner sc = new Scanner(file);
      PrintWriter output = new PrintWriter(outputStr);
      System.out.println("Searching for " + search);
      boolean found = false;
      
      //start clock
      long start = System.currentTimeMillis();
      //searching the file
      while(sc.hasNextLine()){
        count_linear++;
        String word = sc.nextLine();
        if(word.equals(search)){
          System.out.println("String found!");
          found = true;
          break;
        }
      }
      if (!found) {
        System.out.println("String not found");
      }
      //stop clock
      long stop = System.currentTimeMillis();
      //output details and close statements
      output.println("Linear Search Requested");
      output.println("Input file is " + str);
      output.println("Number of comparisons made: " + count_linear);
      time_taken_linear = stop - start; 
      output.println("Time taken: " + time_taken_linear + " Milliseconds");
      input.close();
      in.close();
      sc.close();
      output.close();
      
    }catch(IOException e){
      System.out.println("Something went wrong");
      e.printStackTrace();
    }
  }
  
     /*
   * Conducts a binary search upon the user-inputted file and outputs the details to the user-inputted output file.
   * @return - returns details to the user-inputted output file.
   */
  static void binarySearch() {
    //declare variables
    Scanner input = new Scanner(System.in);
    int count_binary = 0;
    
    //Get files from user
    System.out.println("Enter the name of the file you wish to read: ");
    String str = input.next();
    System.out.println("Enter the name of the file you wish to output to: ");
    String outputStr = input.next();
    
    //Get search query
    System.out.println("Enter the search query");
    Scanner in = new Scanner(System.in);
    String search = in.nextLine();
    try{
      //Read the file
      File file = new File(str);
      Scanner sc = new Scanner(file);
      PrintWriter output = new PrintWriter(outputStr);
      //creating an array list
      ArrayList<String> list = new ArrayList<String>();
      System.out.println("Searching for " + search);
      boolean found = false;
      //adding lines of file to a list
      while(sc.hasNextLine()){
        String word = sc.nextLine();
        list.add(word);     
      }
      //sorting file
      Collections.sort(list);    
      int low =0;
      int high = list.size() - 1;
      int count = 0;
      
      //start clock
      long start1 = System.currentTimeMillis();
      
      //searching file
      while(low <= high){
        count_binary++;
        int mid = (high + low) /2;
        String word = list.get(mid);
        if(word.equals(search)){
           System.out.println(search + " found ");
           found = true;
           break;
        }
        if(word.compareTo(search) < 0){
          low = mid +1;
        }
        if(word.compareTo(search) > 0){
          high = mid - 1;
        }
      }   
      //stop clock
      long stop1 = System.currentTimeMillis();
      
      if(found==false){
        System.out.println("String not found");
      }
      //output details and close statements
      output.println("Binary Search Requested");
      output.println("Input file is " + str);
      output.println("Number of comparisons made: " + count_binary);
      output.println("Time taken: " + (stop1 - start1) + " Milliseconds");
      input.close();
      in.close();
      sc.close();
      output.close();
      
    }catch(IOException e){
      System.out.println("Something went wrong");
      e.printStackTrace();
    }
  }

     /*
   * Conducts a bubble sort upon the user-inputted file and outputs the details to the user-inputted output file.
   * @return - returns details to the user-inputted output file.
   */
  static void bubbleSort() {
    //declaring variables
    Scanner input = new Scanner(System.in);
    System.out.println("Enter the name of the file you wish to read: ");
    String str = input.next();
    System.out.println("Enter the name of the file you wish to output to: ");
    String outputStr = input.next();
    int [] arr = new int [10000];
    int countS = 0;
    int countC = 0;
    int k = 0;
    
    try {
      //assigning input and output files
      File file = new File(str);
      Scanner sc = new Scanner(file);
      PrintWriter output = new PrintWriter(outputStr);
      //start clock
      long start1 = System.currentTimeMillis();
      
      //adding lines of the inputted file to an array
      while (sc.hasNextLine()) {
        arr[k] = sc.nextInt();
        k++;
      }
      //sorting the array
      for(int i=0; i< arr.length-1;i++){
        for(int j=0; j< arr.length-1; j++){
          countC++;
          if(arr[j] > arr[j+1]){
            int temp = arr[j];
            arr[j] = arr[j+1];
            arr[j+1] = temp;
            countS++;
          }     
        }
      }
      //stop clock
      long stop1 = System.currentTimeMillis();
      
      //output details and close statements
      output.println("Bubble Sort Requested");
      output.println("Input file is " + str);
      output.println("Number of comparisons made: " + countC);
      output.println("Number of swaps made: " + countS);
      output.println("Time taken: " + ((start1 - stop1) * -1) + " Milliseconds");
      input.close();
      sc.close();
      output.close();
      
    }catch(IOException e) {
      System.out.println("Something went wrong");
      e.printStackTrace();
    }
  }
  
     /*
   * Conducts a insertion sort upon the user-inputted file and outputs the details to the user-inputted output file.
   * @return - returns details to the user-inputted output file.
   */
  static void insertionSort() {
    //declaring input and output file
    Scanner input = new Scanner(System.in);
    System.out.println("Enter the name of the file you wish to read: ");
    String str = input.next();
    System.out.println("Enter the name of the file you wish to output to: ");
    String outputStr = input.next();
    
    try {
      //assigning input and output file
      File file = new File(str);
      Scanner sc = new Scanner(file);
      PrintWriter output = new PrintWriter(outputStr);
      output.println("Insertion Sort Requested");
      output.println("Input file is " + str);
      output.println("The following has been sorted: \n");
      
      //adding lines of the input file to an array      
      ArrayList<String> lines = new ArrayList<String>();
      while (sc.hasNextLine()) {
        String currentLine = sc.nextLine();
        lines.add(currentLine);
        currentLine = sc.nextLine();
      }
      //Sorting the ArrayList
      Collections.sort(lines);
      for (String line : lines) {
        output.println(line);
      }
      //close statements
      input.close();
      sc.close();
      output.close();
      
    } catch (IOException e) {
      System.out.println("Something went wrong"); 
      e.printStackTrace();
     }
 }
}