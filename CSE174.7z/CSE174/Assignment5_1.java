/**
 * Author: Nicholas Walsh
 * Date: 10/21/2022
 * Description: This program asks the user for an input of a word with the length of 6 or more letters. This word is
 * then passed to the method scramble(). The scramble method takes the word, scrambles two letters in between,
 * leaving the first and last letters untouched. Finally, returns the scrambled word to the user.
**/
import java.util.Scanner;
import java.lang.Math;

public class Assignment5_1{
  
  public static void main(String [] args) {
    
    Scanner input = new Scanner(System.in);
    
   //Declaring Variables
    String word = "";
    
    //Do loop for the user input of a 6 or more lettered word
    do
    {
      System.out.println("Please Enter a Word That Has 6 or More Words: ");
      word = input.next();
    }
    while (word.length() < 6);
    scramble(word);
  }
  
  /*
   * Scramble a word input by the user keeping the first and last letter the same, mixing up two letters in between.
   * @String word - word to be scrambled, for this program, word that had been input by the user.
   * @return - scrambled word.
   */
  static void scramble(String word) {
    //First and Second Random Numbers for Substring
    int randomFirst = 0;
    int randomSecond = 0;
    
    //Do loops to validate authorized numbers
    do
    {
      randomSecond = 1 + (int) (Math.random()*word.length()-2);
    }
    while (randomSecond == 0 || randomSecond >= word.length()-3);
    
    do
    {
      randomFirst = 1 + (int) (Math.random()*word.length()-2);
    }
    while(randomFirst == 0 || randomFirst >= randomSecond);
    
    //Print Statement
    System.out.println(word.substring(0, randomFirst) + word.charAt(randomSecond) + word.substring(randomFirst + 1, randomSecond) 
              + word.charAt(randomFirst) + word.substring(randomSecond + 1, word.length()));
  }
}