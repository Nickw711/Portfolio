/**
 * Author: Nicholas Walsh
 * Description: Lets the user input their periodic payment, interest rate, and number of payments
 * for their annuity. The program then calculates the value of annuity for the user and prints it out.
**/
import java.util.Scanner;
import java.lang.Math;

public class Lab2_1{
  
  public static void main(String [] args) {
    
    Scanner input = new Scanner(System.in);
    
    System.out.print("Please enter your periodic payment: ");
    double periodicPayment = input.nextDouble();
    System.out.print("Please enter your interest rate: ");
    double interest = input.nextDouble();
    System.out.print("Please enter the number of payments: ");
    double payments = input.nextDouble();
    
    double pVann = (periodicPayment * ((Math.pow(1 + interest, payments - 1) - 1) / interest) / (Math.pow((1 + interest), payments - 1) + 1));
    
    System.out.printf("%.2f", pVann);
  }
}
    
    