/**
 * Author: Nicholas Walsh
 * Date: 11/11/2022
 * Description: This program starts by calling the simulateDice method. This method conducts ten thousand random scenarios
 * of two dice throws and an amount gambled between $1-100. This data is then written to dice.txt. A new method is called
 * (writeDetails). This method uses the data from dice.txt, parses it, and calculates the amount won or amount lost in each scenario.
 * This new data is then written in details.txt. Finally the method writeStats is called. This method takes the data from details.txt
 * and calculates new data such as, total amount won and lost, average amount won and lost, largest amount won and lost,
 * and amount of wins and losses. This data is written to stats.txt.
**/
import java.util.Scanner;
import java.lang.Math;
import java.io.*;

public class Lab7_1{
  
  public static void main(String [] args) {
    simulateDice();
  }
  
  
    /*
   * Simulates ten thousand random scenarios of 2 dice throws and an amount gambled between $1-100.
   * @return - returns ten thousand random scenarios of data into the dice.txt file.
   */
    static void simulateDice() {
      //Simulates ten thousand random scenarios
      try {
        PrintWriter diceFile = new PrintWriter("dice.txt");
        diceFile.println("Dice1\tDice2\tAmtGambled");
         for (int i=0; i<10000;i++) {
          int amtGambled = 1 + (int) (Math.random()*99);
          int dice1 = 1 + (int) (Math.random()*5);
          int dice2 = 1 + (int) (Math.random()*5);
          diceFile.println(dice1 + "\t" + dice2 + "\t" + amtGambled);
        }
        diceFile.close();
      }
      catch (IOException e) {
        System.out.println("An error occurred in the first try-catch block.");
        e.printStackTrace();
    }
      writeDetails();
  }
    
    
    /*
   * Reads data from dice.txt.
   * Calculates the amount of money won and lost for each scenario.
   * @return - returns ten thousand scenarios of data including the wins and losses of each to details.txt.
   */
    static void writeDetails() {
      //Declaring variables
      int dice1 = 0;
      int dice2 = 0;
      int amtGambled = 0;
      double amtWon = 0;
      double amtLost = 0;
      
      //Gathers data from dice.txt, parses the data, calculates amount won or amount lost
      //Writes new data to details.txt
      try {
        File inputFile = new File("dice.txt");
        PrintWriter output = new PrintWriter("details.txt");
        Scanner input = new Scanner(inputFile);
        output.println("Dice1\tDice2\tAmtGambled\tAmtWon\tAmtLost");
        for (int i=0; i<10000;i++) {
          input.nextLine();
          if (input.hasNextInt()) {
            dice1 = Integer.parseInt(input.next());
          }
          if (input.hasNextInt()) {
            dice2 = Integer.parseInt(input.next());
          }
          if (input.hasNextInt()) {
            amtGambled = Integer.parseInt(input.next());
          }
          
          if (dice1 + dice2 < 5) {
            amtLost = amtGambled * .70;
          }
          else if (dice1 + dice2 < 10) {
            amtLost = amtGambled * .40;
          }
          else if (dice1 + dice2 >= 10) {
            amtWon = amtGambled * 2;
          }
          output.println(dice1 + "\t" + dice2 + "\t" + amtGambled + "\t\t" + amtWon + "\t" + String.format("%.2f", amtLost));
          amtWon = 0;
          amtLost = 0;
        }
        output.close();
        input.close();
      }
      catch (IOException e) {
        System.out.println("An error occurred in the second try-catch block.");
        e.printStackTrace();
      }
      writeStats();
    }
    
    
    /*
   * Reads data from details.txt
   * Calculates number of wins and losses as well as the total amount of money won and lost, the average of each, and
   * the largest of all data.
   * @return - returns total amount won and lost, average amount won and lost, largest amount won and lost, and amount of wins and losses to stats.txt.
   */
    static void writeStats() {
      //Declaring Variables
      double largestWin = 0;
      double largestLoss = 0;
      double totalWinAmt = 0;
      double totalLossAmt = 0;
      double amtOfLosses = 0;
      double amtOfWins = 0;
      double averageLoss = 0;
      double averageWin = 0;
      double checkDouble = 0;
      
      //Gathers data from details.txt, parses data, calculates amount won, amount lost, the average of each, and largest of each 
      try {
        File inputFile = new File("details.txt");
        PrintWriter output = new PrintWriter("stats.txt");
        Scanner input = new Scanner(inputFile);
        do {
          input.nextLine();
          if (input.hasNextInt()) {
            int dice1 = Integer.parseInt(input.next());
          }
          if (input.hasNextInt()) {
            int dice2 = Integer.parseInt(input.next());
          }
          if (input.hasNextInt()) {
            int amtGambled = Integer.parseInt(input.next());
          }
          if (input.hasNextDouble()) {
            checkDouble = input.nextDouble();
            if (checkDouble !=0) {
              totalWinAmt += checkDouble;
              amtOfWins++;
              if (checkDouble > largestWin) {
                largestWin = checkDouble;
              }
            }
          }
          checkDouble = 0;
          if (input.hasNextDouble()) {
            checkDouble = input.nextDouble();
            if (checkDouble != 0) {
              totalLossAmt += checkDouble;
              amtOfLosses++;
              if (checkDouble > largestLoss) {
                largestLoss = checkDouble;
              }
            }
          }
          checkDouble = 0;
        }
        while (input.hasNextLine());
        if (amtOfLosses > 0) {
          averageLoss = totalLossAmt / amtOfLosses;
        }
        if (amtOfWins > 0) {
          averageWin = totalWinAmt / amtOfWins;
        }
        //Writes the data to stats.txt
        output.println("Total Amount Won: " + String.format("%.2f", totalWinAmt));
        output.println("Total Amount Lost: " + String.format("%.2f", totalLossAmt));
        output.println("Average Amount Won: " + String.format("%.2f", averageWin));
        output.println("Average Amount Lost: " + String.format("%.2f", averageLoss));
        output.println("Largest Amount Won: " + String.format("%.2f", largestWin));
        output.println("Largest Amount Lost: " + String.format("%.2f", largestLoss));
        output.println("Amount of Wins: " + amtOfWins);
        output.println("Amount of Losses: " + amtOfLosses);
        output.close();
        input.close();
      }
      catch (IOException e) {
        System.out.println("An error occured in the third try-catch block.");
        e.printStackTrace();
      }
    }
}