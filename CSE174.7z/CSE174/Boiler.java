import java.util.*;
import java.lang.*;
import java.io.*;

public class Boiler{
  
  public static void main(String [] args) {
    readFile();
  }
  
  
  
  static void readFile() {
      //Simulates ten thousand random scenarios
    Scanner in = new Scanner(System.in);
    String userInput = "";
    ArrayList<String> lines = new ArrayList<String>();
    
    try {
        System.out.println("Enter the file you wish to reverse (\"example.txt\"): ");
        userInput = in.next();
        File file = new File(userInput);
        Scanner input = new Scanner(file);
        
        while(input.hasNextLine()) {
          String line = input.nextLine();
          String newLine = "";
          for (int i = line.length() -1; i >=0; i--) {
            char c = line.charAt(i);
            newLine = newLine + c;
          }
          lines.add(newLine);
        }
        
        input.close();
      } catch (FileNotFoundException e) {
        System.out.println("An error occurred in the first try-catch block.");
        e.printStackTrace();
    }
      writeFile(userInput, lines);
  }
  
  
  
  static void writeFile(String fileInput, ArrayList<String> lines) {
    try {
        File file = new File(fileInput);
        Scanner input = new Scanner(file);
        PrintWriter output = new PrintWriter(file);
        
        for (int i=0; i <= lines.size()-1; i++) {
          output.println(lines.get(i));
        }
        
        input.close();
        output.close();
      } catch (IOException e) {
        System.out.println("An error occurred in the first try-catch block.");
        e.printStackTrace();
    }
