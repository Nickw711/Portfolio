/**
 * Author: Nicholas Walsh
 * Date: 10/3/2022
 * Description: Once ran, the program creates 10 random numbers between 1 and 20. The program then calculates the largest
 * number out of the 10 random numbers. The program also determines whether there is more than one six. Finally, the program
 * prints out the 10 generated numbers, a statement if there is more or less than 2 sixes, and a multiplication table that
 * continues until the largest number that was found is reached.
**/
import java.util.Scanner;
import java.lang.Math;

public class Assignment4_1{
  
  public static void main(String [] args) {
    
    Scanner input = new Scanner(System.in);
    
    
   //Declaring Variables
    String numberOutput = "";
    int largestNumber = 0;
    int sixCounter = 0;
    
    
    //For loop for random numbers
    for (int i=0; i<10; i++)
    {
      int randomNumber = 1 + (int) (Math.random()*20);
      numberOutput = numberOutput + " " + randomNumber;
      if (randomNumber > largestNumber)
      {
        largestNumber = randomNumber;
      }
      if (randomNumber == 6)
      {
        sixCounter++;
      }
    }
    
    
    //Print Statements
    System.out.println("Generating 10 random numbers between 1 and 20...");
    System.out.println(numberOutput + "\n");
    if (sixCounter > 1)
    {
      System.out.println("HURRAY!! DOUBLE SIXES GENERATED!");
    }
    else
    {
      System.out.println("SORRY!! DOUBLE SIXES NOT ENCOUNTERED!");
    }
    System.out.println("Largest random number is: " + largestNumber + "\n");
    
    System.out.println("The multiplication table is as follows:");
    for (int i=1; i <= largestNumber; i++)
    {
      System.out.println(i + " " + i*2 + " " + i*3 + " " + i*4 + " " + i*5 + " " + i*6 + " " + i*7 + " " + i*8 + " " + i*9 + " " + i*10);
    }
   input.close();
  }
}