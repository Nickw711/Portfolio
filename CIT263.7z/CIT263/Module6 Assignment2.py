"""
Author: Nicholas Walsh
Date: 3/06/2023
Description: Class that includes one dunder function and three methods. User can input fuel and highest gear at instantiation. The user can then start,
accelerate, and stop the car. The car will automatically stop if it is out of fuel. The car will not go any faster than the highest gear but will
still use fuel if you try to accelerate past the highest gear.
"""
class Taurus():
    def __init__(self, fuel, highestGear):
        self.fuel = fuel
        self.highestGear = highestGear
        self.currentGear = 0
        print("Fuel:", self.fuel, "Current Gear:", self.currentGear)

    def Start(self):
        if self.fuel > 0:
            print("Starting Engine")
            self.fuel -= 1
        else:
            print("You are out of fuel!")
            self.Stop()

        print("Current Fuel:", self.fuel, "Current Gear:", self.currentGear)
    
    def Accelerate(self): 
        if self.fuel > 0:
            self.fuel -= 1
        else:
            print("You are out of fuel!")
            self.Stop()
        

        if self.currentGear < self.highestGear:
            self.currentGear += 1
        else:
            print("You are in the highest gear!")

        print("Current Fuel:", self.fuel, "Current Gear:", self.currentGear)
        
    def Stop(self):
        print("Stopping Car")
        self.currentGear = 0
        


myCar = Taurus(10, 6)

myCar.Start()
myCar.Accelerate()
myCar.Accelerate()
myCar.Accelerate()
myCar.Accelerate()
myCar.Accelerate()
myCar.Stop()