"""
Author: Nicholas Walsh
Date: 02/01/2023
Description: Uses the time module for the time since "the epoch". The program converts this time into standard time(Days, Hours, Minutes, and Seconds).
The standard time since the epoch is then printed into the console.
"""
import time
TIME = time.time()
MINUTE = 60
HOUR = MINUTE*60
DAY = HOUR*24

Days = TIME//DAY
Hours = ((TIME/DAY) - Days) *  DAY / HOUR
Minutes = (Hours - int(Hours))* 60
Seconds = (Minutes - int(Minutes))* 60

print("Days Since Epoch:\nDays:", int(Days), "\tHours:", int(Hours), "\tMinutes:", int(Minutes), "\tSeconds:", int(Seconds))
