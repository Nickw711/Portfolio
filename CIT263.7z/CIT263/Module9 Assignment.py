import tkinter as tk
from tkinter import messagebox
from tkinter import *
class Card:
    def __init__(self, suit, rank):
        """Create a new card object suit and rank"""
        self.suit = suit
        self.rank = rank
        # NOTE: __init__() methods NEVER have a return statement.

import random
class Deck:
    def __init__(self):
        """Create a new deck object"""
        self.deck = []
        self.current = 0
        suit = ""
        rank = ""
        for decks in range(0, 6):
            for s in range(1, 5):
                if s == 1:
                    suit = "hearts"
                elif s == 2:
                    suit = "spades"
                elif s == 3:
                    suit = "diamonds"
                elif s == 4:
                    suit = "clubs"
                for r in range(1, 14):
                    if r == 1:
                        rank = "ace"
                    elif r == 11:
                        rank = "jack"
                    elif r == 12:
                        rank = "queen"
                    elif r == 13:
                        rank = "king"
                    else: 
                        rank = str(r) 
                    card = Card(suit, rank)
                    self.deck.append(card)
        # NOTE: __init__() methods NEVER have a return statement.

    def shuffle(self):
        """The shuffle cards in deck."""
        random.shuffle(self.deck)
        self.current = 0

    def deal(self):
        """gets next card in deck."""
        card = self.deck[self.current]
        self.current += 1
        return card
        
class Hand():
    def __init__(self):
        """Create a new card object suit and rank"""
        self.cards = []
        # NOTE: __init__() methods NEVER have a return statement.

    def addCard(self, card):
        self.cards.append(card)

    def value(self):
        """The value of a card object."""
        val = 0
        aces = 0
        for card in self.cards:
            if card.rank == "ace":
                aces += 1
            elif card.rank == "jack" or card.rank == "queen" or card.rank == "king":
                val = val + 10  
            else:
                val = val + int(card.rank)  
        if aces > 0:  
            val = val + aces
            if val < 12:
                val = val + 10
        return val
    
    def isBlackJack(self):
        blackjack = False
        if (self.value() == 21) and (len(self.cards) == 2):
            blackjack = True
        return blackjack
    
    def isSoft17(self):
        soft17 = False
        if len(self.cards) == 2 and self.value() == 17:
            for card in self.cards:
                if card.rank == "ace":
                    soft17 = True
        return soft17

    def __str__ (self):
        hand = ""
        for c in range(len(self.cards)):
            hand = hand + self.cards[c].rank + " of " + self.cards[c].suit
            if c < len(self.cards) - 1:
                hand = hand + ", "
        return hand

class Blackjack(tk.Tk):
    def __init__(self):
        super().__init__()
        self.geometry("535x350")
        self.title("BlackJack 1.0")
        self.configure(bg='lightgrey')

        self.windowTitle = Label(bg='lightgrey',text="BlackJack 1.0").grid(row=0,column=3,columnspan=5)

        self.hitButton = Button(bg='lightgrey',text="Hit",width= 10,height=2,command=self.hit)
        self.hitButton.grid(row=3,column=2,columnspan=3)
        self.standButton = Button(bg='lightgrey',text="Stand",width=10,height=2,command=self.stand).grid(row=3,column=5,columnspan=3)

        self.dealerLabel = Label(bg='lightgrey',text="Dealer Shows: ")
        self.dealerLabel.grid(row=1,column=3,columnspan=5)
        self.playerLabel = Label(bg='lightgrey',text="Player Has: ")
        self.playerLabel.grid(row=2,column=3,columnspan=5)

        self.textArea = Text(self,height=10,width=65)
        self.textArea.grid(row=5,column=3,rowspan=5,columnspan=5)
        self.textArea.insert(END,"Click Deal to Start The Game!\nPlayer Holds:\nDealer Holds:\n")

        self.dealButton = Button(bg='lightgrey',text="Deal",width=10,height=2,command=self.deal).grid(row=15,column=2,columnspan=3)
        self.quitButton = Button(bg='lightgrey',text="Quit",width=10,height=2,command=self.quitGame).grid(row=15,column=5,columnspan=3)

    def deal(self):
        if self.hitButton["state"] == DISABLED:
            self.hitButton["state"] = NORMAL
        self.player = Hand()
        self.dealer = Hand()
        self.deck = Deck()
        self.deck.shuffle()
        for d in range(2):
            self.player.addCard(self.deck.deal())
            self.dealer.addCard(self.deck.deal())
        self.dealerLabel.configure(text="Dealer Shows: "+self.dealer.cards[1].rank+" of "+self.dealer.cards[1].suit)
        self.playerLabel.configure(text="Player Has: "+str(self.player))
        self.textArea.delete("1.0", END)
        self.textArea.insert(END,"Players Turn\nPlayer Holds: "+str(self.player)+"\nDealer Shows: "+self.dealer.cards[1].rank+" of "+self.dealer.cards[1].suit)
        
        if self.player.isBlackJack():
            self.textArea.delete("1.0", END)
            self.textArea.insert(END,"Player Stands\nPlayer Holds: "+str(self.player)+"\nDealer Shows: "+self.dealer.cards[1].rank+" of "+self.dealer.cards[1].suit+
                            "\nPlayer has BlackJack\nPlayer Wins!")
        if self.dealer.isBlackJack():
            self.textArea.delete("1.0", END)
            self.textArea.insert(END,"Dealer Stands\nPlayer Holds: "+str(self.player)+"\nDealer Shows: "+self.dealer.cards[1].rank+" of "+self.dealer.cards[1].suit+
                            "\nDealer has BlackJack\nDealer Wins!")

    def hit(self):
        self.player.addCard(self.deck.deal())
        self.textArea.delete("1.0", END)
        self.textArea.insert(END,"Player Taking Card\nPlayer Holds: "+str(self.player)+"\nDealer Shows: "+self.dealer.cards[1].rank+" of "+self.dealer.cards[1].suit)
        if self.player.value() > 21:
            self.textArea.delete("1.0", END)
            self.textArea.insert(END,"Player Busts!\nPlayer Holds: "+str(self.player)+"\nDealer Shows: "+self.dealer.cards[1].rank+" of "+self.dealer.cards[1].suit+
                            "\nDealer Wins!")

    def stand(self):
        self.hitButton["state"] = DISABLED
        self.dealerLabel.configure(text="Dealer Holds: "+str(self.dealer))
        while self.dealer.value() < 17 or self.dealer.isSoft17():
            self.dealer.addCard(self.deck.deal())
            self.textArea.delete("1.0", END)
            self.textArea.insert(END, "Dealer Taking Card\nPlayer Holds: "+str(self.player)+"\nDealer Holds: "+str(self.dealer))
        
        if self.dealer.value() == 21:
            self.textArea.delete("1.0", END)
            self.textArea.insert(END, "Dealer Stands\nPlayer Holds: "+str(self.player)+"\nDealer Holds: "+str(self.dealer)+"\nDealer Has BlackJack")
            
        if self.dealer.value() > 21:
            self.textArea.delete("1.0", END)
            self.textArea.insert(END, "Dealer Busts!\nPlayer Holds: "+str(self.player)+"\nDealer Holds: "+str(self.dealer)+"\nPlayer Wins!")
            
        elif self.player.value() == self.dealer.value():
            self.textArea.delete("1.0", END)
            self.textArea.insert(END, "Dealer Stands\nPlayer Holds: "+str(self.player)+"\nDealer Holds: "+str(self.dealer)+"\nIt's A Push!")
            
        elif self.player.value() > self.dealer.value():
            self.textArea.delete("1.0", END)
            self.textArea.insert(END, "Dealer Stands\nPlayer Holds: "+str(self.player)+"\nDealer Holds: "+str(self.dealer)+"\nPlayer Wins!")
            
        else:
            self.textArea.delete("1.0", END)
            self.textArea.insert(END, "Dealer Stands\nPlayer Holds: "+str(self.player)+"\nDealer Holds: "+str(self.dealer)+"\nDealer Wins!")
    def quitGame(self):
        messagebox.showerror("Shutting Down", "Quitting Game")
        self.destroy()
if __name__ == "__main__":
  root = Blackjack()
  root.mainloop()
