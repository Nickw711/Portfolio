"""
Author: Joseph Kennedy
Description: This program simulates a simple game of blackjack
"""
'''
Editor: Nicholas Walsh
Date: 3/09/2023 - 3/13/2023
Description: Added session class, added isBlackJack and isSoft17 method to hand class, player and dealers cards now show the value under their hand,
the game is now played with 6 decks of cards, the hand ends when either the dealer or player gets blackjack in their first two cards.
'''
class Card:
    def __init__(self, suit, rank):
        """Create a new card object suit and rank"""
        self.suit = suit
        self.rank = rank
        # NOTE: __init__() methods NEVER have a return statement.

import random
class Deck:
    def __init__(self):
        """Create a new deck object"""
        self.deck = []
        self.current = 0
        suit = ""
        rank = ""
        for decks in range(0, 6):
            for s in range(1, 5):
                if s == 1:
                    suit = "hearts"
                elif s == 2:
                    suit = "spades"
                elif s == 3:
                    suit = "diamonds"
                elif s == 4:
                    suit = "clubs"
                for r in range(1, 14):
                    if r == 1:
                        rank = "ace"
                    elif r == 11:
                        rank = "jack"
                    elif r == 12:
                        rank = "queen"
                    elif r == 13:
                        rank = "king"
                    else: 
                        rank = str(r) 
                    card = Card(suit, rank)
                    self.deck.append(card)
        # NOTE: __init__() methods NEVER have a return statement.

    def shuffle(self):
        """The shuffle cards in deck."""
        random.shuffle(self.deck)
        self.current = 0

    def deal(self):
        """gets next card in deck."""
        card = self.deck[self.current]
        self.current += 1
        return card
        
class Hand():
    def __init__(self):
        """Create a new card object suit and rank"""
        self.cards = []
        # NOTE: __init__() methods NEVER have a return statement.

    def addCard(self, card):
        self.cards.append(card)

    def value(self):
        """The value of a card object."""
        val = 0
        aces = 0
        for card in self.cards:
            if card.rank == "ace":
                aces += 1
            elif card.rank == "jack" or card.rank == "queen" or card.rank == "king":
                val = val + 10  
            else:
                val = val + int(card.rank)  
        if aces > 0:  
            val = val + aces
            if val < 12:
                val = val + 10
        return val
    
    def isBlackJack(self):
        blackjack = False
        if (self.value() == 21) and (len(self.cards) == 2):
            blackjack = True
        return blackjack
    
    def isSoft17(self):
        soft17 = False
        if len(self.cards) == 2 and self.value() == 17:
            for card in self.cards:
                if card.rank == "ace":
                    soft17 = True
        return soft17

    def __str__ (self):
        hand = ""
        for c in range(len(self.cards)):
            hand = hand + self.cards[c].rank + " of " + self.cards[c].suit
            if c < len(self.cards) - 1:
                hand = hand + ", "
        return hand

class Session():
    def __init__(self):
        self.bankroll = 200.00
        self.bet = 0.0
        self.winnings = 0
        self.losses = 0
        self.hands_won = 0
        self.hands_lost = 0
        self.hands_tied = 0

    def betAmount(self):
        self.bet = float(input("Choose an amount to bet(less than your bankroll): "))
        if self.bet > self.bankroll:
            self.betAmount()
    
    def winOutcome(self, outcome):
        if outcome == "win":
            self.bankroll = self.bankroll + self.bet
            self.winnings = self.winnings + self.bet
            self.hands_won += 1
        elif outcome == "tie":
            self.hands_tied += 1
        elif outcome == "loss":
            self.bankroll = self.bankroll - self.bet
            self.losses = self.losses + self.bet
            self.hands_lost += 1

    def __str__(self):
        return ("Bankroll: " + str(self.bankroll) + " Winnings: " + str(self.winnings) + " Losses: " + str(self.losses) + " Hands Won: " + str(self.hands_won) + 
                   " Hands Lost: " + str(self.hands_lost) + " Hands Tied: " + str(self.hands_tied))

session = Session()
deal = "D"
while deal.upper() == "D":
    dealer = Hand()
    player = Hand()     
    deck = Deck()
    deck.shuffle()
    #If player out of money, end game
    if session.bankroll <= 0:
        print("Player out of money, ending game.")
        break
    #Ask player how much he wants to bet
    session.betAmount()
    #deal cards to dealer and player
    for d in range(2):
        player.addCard(deck.deal())
        dealer.addCard(deck.deal())
    #show dealer top card
    print("Dealer shows: " + dealer.cards[1].rank + " of " + dealer.cards[1].suit, "\n")

    #show player hand
    print("Player holds: " + str(player), "\nPlayer Value:", player.value(), "\n")

    #player turn
    stand = False
    #Check for blackjack within dealer and player hands after deal
    if player.isBlackJack() or dealer.isBlackJack():
        stand = True
    while player.value() < 22 and stand == False:
        if player.value() == 21:
            print("Player has BlackJack")
            session.winOutcome("win")
            break
        choice = input("Enter H to hit or S to stand ")
        if choice.upper() == "S":
            stand = True
        elif choice.upper() == "H":
            print("Player taking card")
            player.addCard(deck.deal())
            print("Player holds: " + str(player), "\nPlayer Value:", player.value(), "\n")
        else:
            print("You must enter an S or H")

    #if player bust, hand over
    if player.value() > 21:
        print("Player busts, dealer wins")
        session.winOutcome("loss")
    else:
        #dealer turn
        print("Dealer holds: " + str(dealer), "\nDealer Value:", dealer.value(), "\n")
        stand = False
        #Check for blackjack within dealer and player hands after deal
        if player.isBlackJack() or dealer.isBlackJack():
            stand = True
        if stand == False:
            while dealer.value() < 17 or dealer.isSoft17():
                print("Dealer taking card")
                dealer.addCard(deck.deal())
                print("Dealer holds: " + str(dealer), "\nDealer Value:", dealer.value(), "\n")

        if dealer.value() == 21:
            print("Dealer has BlackJack")
            session.winOutcome("loss")
            
        if dealer.value() > 21:
            print("Dealer busts, player wins")
            session.winOutcome("win")
        elif player.value() == dealer.value():
            print("It's a push")
            session.winOutcome("tie")
        elif player.value() > dealer.value():
            print("Player wins")
            session.winOutcome("win")
        else:
            print("Dealer wins")
            session.winOutcome("loss")
    deal = ""
    while deal.upper() != "D" and deal.upper() != "Q":
        deal = input("Enter D to deal or Q to quit ")
print(session)