"""
Author: Nicholas Walsh
Date: 02/12/2023
Description: This program contains a function, rotate_word, that the user can call with a string and integer parameter. Each letter in the string
is rotated by the integer parameter using the ord function and turned back into a letter using the chr function.
"""
def rotate_word(word, rotation):
    rotated_word = ""
    word = word.lower()
    for letter in word:
        rotated_ord = ord(letter) + rotation
        rotated_letter = chr(rotated_ord)
        rotated_word += rotated_letter
    print(rotated_word)

rotate_word("cheer", 7)