"""
Author: Nicholas Walsh
Date: 3/06/2023
Description: Uses datetime plugin and two functions to find out what day of the week it is today, the users age in years and days, and how many days there
are until the users next birthday.
"""
from datetime import date

#function that determines what day of the week it is today using thhe datetime plugin.
def todaysWeekday():
    weekdays = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Friday"]

    today = date.today()
    today = str(today)

    todaysDate = today.split("-")

    year = int(todaysDate[0])
    month = int(todaysDate[1])
    day = int(todaysDate[2])

    weekday = date(year, month, day).isoweekday()
    weekday -= 1
    print("Today is", weekdays[weekday])


#user inputs their birthyear, birthmonth, and birthday into the function to have their age and time until their next birthday displayed.
def birthdayCalculator(birthYear, birthMonth, birthDay):
    today = date.today()
    yourBirthday = date(birthYear, birthMonth, birthDay)

    yourAge = (today - yourBirthday)
    yourAge = str(yourAge).split()
    ageInDays = int(yourAge[0])
    years = ageInDays // 365
    days = int((ageInDays / 365 - years) * 365)
    print("You are", years, "years and", days, "days old")

    yourBirthday = date(today.year, birthMonth, birthDay)
    timeTilBday = abs(yourBirthday - today)
    timeTilBday = str(timeTilBday).split()
    print("There are", timeTilBday[0], "days until your next birthday")

todaysWeekday()
birthdayCalculator(2002, 7, 11)