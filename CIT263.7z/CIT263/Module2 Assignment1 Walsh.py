"""
Author: Nicholas Walsh
Date: 02/01/2023
Description: This program includes a function that allows the user to enter a column and row integer
creating a grid based on these values.
"""
def printGrid(columns, rows):
    print("+ - - - - "*columns + "+")
    while rows > 0:
        rows-= 1
        print("|         "*columns + "|")
        print("|         "*columns + "|")
        print("|         "*columns + "|")
        print("|         "*columns + "|")
        print("+ - - - - "*columns + "+")

printGrid(4, 4)