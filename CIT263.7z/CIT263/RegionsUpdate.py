"""
Author: Joseph Kennedy
Description: This program provides an interface to update the regions table
Edited By: Nicholas Walsh
Description: Added sql code to insertClick, updateClick, and deleteClick functions.
Added an askyesno messagebox for deleteClick function to authorize deletion of a record.
Added sqlite code to commit insert, update, and delete functions to the database.
"""
import sqlite3
import tkinter as tk
from tkinter.messagebox import askyesno

class RegionsUpdate(tk.Tk):
    def __init__(self):
        super().__init__()

        self.geometry("400x450")

        self.title("Region Update")

        self.layout_frame = tk.Frame(master=self)
        self.layout_frame.columnconfigure(0, minsize=200)
        self.layout_frame.columnconfigure(1, minsize=200)
        
        self.layout_frame.rowconfigure(0, minsize=50)
        self.layout_frame.rowconfigure(1, minsize=50)
        self.layout_frame.rowconfigure(2, minsize=80)
        self.layout_frame.rowconfigure(3, minsize=80)
        self.layout_frame.rowconfigure(4, minsize=50)
        
        self.id_label = tk.Label(master=self.layout_frame, text="Region ID", width=20)
        self.id_label.grid(row=0, column=0)
        self.id_entry = tk.Entry(master=self.layout_frame, width=20)
        self.id_entry.grid(row=0, column=1)

        self.desc_label = tk.Label(master=self.layout_frame, text="Region Description", width=20)
        self.desc_label.grid(row=1, column=0)
        self.desc_entry = tk.Entry(master=self.layout_frame, width=20)
        self.desc_entry.grid(row=1, column=1)
        
        self.select_button = tk.Button(master=self.layout_frame, text="Select", width=10, height=3, command=self.selectClick)
        self.select_button.grid(row=2, column=0)
        self.insert_button = tk.Button(master=self.layout_frame, text="Insert", width=10, height=3, command=self.insertClick)
        self.insert_button.grid(row=3, column=0)
        self.update_button = tk.Button(master=self.layout_frame, text="Update", width=10, height=3, command=self.updateClick)
        self.update_button.grid(row=2, column=1)
        self.delete_button = tk.Button(master=self.layout_frame, text="Delete", width=10, height=3, command=self.deleteClick)
        self.delete_button.grid(row=3, column=1)
        
        self.result_label = tk.Label(master=self.layout_frame, text="")
        self.result_label.grid(row=4, column=0, columnspan=2)
   
        self.layout_frame.pack()

    def processQuery(self, sql):
        self.result_label["text"] = ""
        self.desc_entry.delete(0, tk.END)

        conn = sqlite3.connect('northwind.db')
        cursor = conn.execute(sql)

        for row in cursor:
            self.desc_entry.delete(0, tk.END)
            self.desc_entry.insert(0, row[1])
            self.result_label["text"] = "Data Found"

        conn.close()

    def selectClick(self):
        try:
            sql = "Select RegionID, RegionDescription \
                from Regions \
                Where RegionID = " + self.id_entry.get() + ";"
            self.processQuery(sql)
        except:
            self.result_label["text"] = "Error Occured"
        
    def processUpdate(self, sql):
        #processes the sql code for insertClick, updateClick, and deleteClick
        self.result_label["text"] = ""
        conn = sqlite3.connect('northwind.db')
        conn.execute(sql)
        conn.commit()
        conn.close()
        self.result_label["text"] = "Data Updated"

    def insertClick(self):
        #Added sql code for insert function
        try:
            sql = "Insert into Regions (RegionID, RegionDescription) values (" + self.id_entry.get() + ",'" + self.desc_entry.get() + "');"
            self.processUpdate(sql)
        except:
            self.result_label["text"] = "Error Occured"
    def updateClick(self):
        #Added sql code for update function
        try:
            sql = "Update Regions set RegionDescription = '" + self.desc_entry.get() + "' where RegionID = " + self.id_entry.get() + ";"
            self.processUpdate(sql)
        except:
            self.result_label["text"] = "Error Occured"
    def deleteClick(self):
        #added askyesno confirmation to double check whether the user actually wants to delete the record or not
        confirmation = askyesno("Confirmation","Are you sure you want to delete this record?")
        if confirmation:
            #Added sql code for delete function
            try:
                sql = "Delete from Regions where RegionID = " + self.id_entry.get() + ";"
                self.processUpdate(sql)
            except:
                self.result_label["text"] = "Error Occured"
        else:
            return

if __name__ == "__main__":
    rps = RegionsUpdate()
    rps.mainloop()
