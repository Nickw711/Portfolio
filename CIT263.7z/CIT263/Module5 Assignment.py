"""
Author: Nicholas Walsh
Date: 2/22/23
Description: The function sed, takes four parameters. A string you are searching for, a string to replace this string, an input file, and an output file.
The function makes all the letters lower case because the replacement is case sensitive. A for loop is used to go through each line in your input file,
replacing each pattern string with the replacement string. Each line is written into the output file.
"""
import sys

def sed(patternString, replacementString, inputFilePath, outputFilePath):
    try:
        input = open(inputFilePath, 'r')
        output = open(outputFilePath, 'w')
        for line in input:
            line = line.lower()
            output.write(line.replace(patternString, replacementString))
        input.close()
        output.close()
    except:
        print("Something went wrong")

def main():
    sed("he", "she", "C:\\Users\\Nicholas\Desktop\\CIT263\\input.txt", "C:\\Users\\Nicholas\Desktop\\CIT263\\output.txt")

if __name__ == '__main__':
    main()