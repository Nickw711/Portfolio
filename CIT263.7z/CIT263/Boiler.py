import sys

def readFile(path):
    try:
        input = open(path, 'r')
        for line in input:
            print(line)
        input.close()
    except:
        print("something went wrong")

readFile("C:\\Users\\Nicholas\\Desktop\\CIT263\\")
