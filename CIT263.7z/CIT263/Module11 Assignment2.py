'''
Author: Nicholas Walsh
Description: A GUI Program that allows you to look up a stock by its ticker symbol.
Once you click submit, the company name and stock price of that ticker symbol will appear.
'''

import tkinter as tk
import pip._vendor.requests
import json

class RegionsUpdate(tk.Tk):
    def __init__(self):
        super().__init__()

        #Creating the layout
        self.geometry("500x250")
        self.title("Stock Lookup")

        self.layout_frame = tk.Frame(master=self)
        self.layout_frame.columnconfigure(0, minsize=200)
        self.layout_frame.columnconfigure(1, minsize=200)
        
        self.layout_frame.rowconfigure(0, minsize=50)
        self.layout_frame.rowconfigure(1, minsize=50)
        self.layout_frame.rowconfigure(2, minsize=80)
        self.layout_frame.rowconfigure(3, minsize=80)
        self.layout_frame.rowconfigure(4, minsize=50)
        
        self.ticker_label = tk.Label(master=self.layout_frame, text="Ticker Symbol", width=20)
        self.ticker_label.grid(row=0, column=0)
        self.ticker_entry = tk.Entry(master=self.layout_frame, width=20)
        self.ticker_entry.grid(row=0, column=1)

        self.name_label = tk.Label(master=self.layout_frame, text="Company Name", width=20)
        self.name_label.grid(row=1, column=0)
        self.nameResult_label = tk.Label(master=self.layout_frame, text="", width=20)
        self.nameResult_label.grid(row=1, column=1)


        self.price_label = tk.Label(master=self.layout_frame, text="Stock Price", width=20)
        self.price_label.grid(row=2, column=0)
        self.priceResult_label = tk.Label(master=self.layout_frame, text="", width=20)
        self.priceResult_label.grid(row=2, column=1)
        
        self.submit_button = tk.Button(master=self.layout_frame, text="Submit", width=10, height=1, command=self.submitClick)
        self.submit_button.grid(row=0, column=2)

        self.result_label = tk.Label(master=self.layout_frame, text="",width=20)
        self.result_label.grid(row=3, column=0, columnspan=3)
        
   
        self.layout_frame.pack()

    #submitClick button that uses the .get() function as well as the api function to recieve the entry of the ticker symbol, helping find the
        #company name and stock price based on the the provided ticker symbol
    def submitClick(self):
        try:
            self.result_label["text"]= ""
            findName = pip._vendor.requests.get("https://query2.finance.yahoo.com/v1/finance/search?q=" + self.ticker_entry.get(), headers={'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36'})
            findPrice = pip._vendor.requests.get("https://query1.finance.yahoo.com/v11/finance/quoteSummary/" + self.ticker_entry.get() + "?modules=financialData", headers={'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36'})
            companyName = json.loads(findName.text) ['quotes'][0]['shortname']
            stockPrice = json.loads(findPrice.text)['quoteSummary']['result'][0]['financialData']['currentPrice']['fmt']

            self.nameResult_label['text'] = companyName
            self.priceResult_label['text'] = stockPrice
        except:
            self.result_label["text"]= "Error Occured"
if __name__ == "__main__":
    rps = RegionsUpdate()
    rps.mainloop()
