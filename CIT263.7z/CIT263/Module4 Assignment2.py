"""
Author: Nicholas Walsh
Date: 02/20/2023
Description: The function "addToInventory" takes a dictionary and list parameter. The function adds the items in the list to the dictionary. If an item in the list is
already in the dictionary, it increments the value of the item by one. If an item in the list is not in the dictionary, the item is added to the dictionary.
"""
#stuff = {'rope': 1, 'torch': 6, 'gold coin': 42, 'dagger': 1, 'arrow': 12}

inv = {'gold coin': 42, 'rope': 1}
dragonLoot = ['gold coin', 'dagger', 'gold coin', 'gold coin', 'ruby']

def addToInventory(inventory, addedItems):
    for element in addedItems:
        if element in inventory:
            inventory[element] += 1
        else:
            inventory.update({element: 1})

    displayInventory(inventory)

def displayInventory(inventory):
    print("Inventory:")
    item_total = 0
    for k, v in inventory.items():
        item_total += v
        print(k, v)
    print("Total number of items: " + str(item_total))


inv = addToInventory(inv, dragonLoot)
