"""
Author: Nicholas Walsh
Date: 03/27/2023
Description: Uses tkinter to create gui with a text entry box and a button that states, "edit". 
The use may type sentances into the text entry. Once the user clicks the button, the text entry will
correct any capitalization errors after the end of a sentance.
"""
from tkinter import *
window = Tk()

def edit():
    needsUpper = False
    counter = 0
    
    enteredText = textEntry.get()
    textEntry.delete(0, "end")
    enteredText = enteredText.capitalize()
    
    for letter in enteredText:
        if letter != " ":
            if needsUpper:
                letter = letter.upper()
            needsUpper = False
            if letter == "." or letter == "?":
                needsUpper = True
            textEntry.insert(counter, letter)
        else:
            textEntry.insert(counter, letter)
        counter += 1


        
textEntry = Entry(width=50)
editButton = Button(master=window, text="Edit", width=20, height=5, command=edit)
textEntry.pack()
editButton.pack()

mainloop()
