"""
Author: Joseph Kennedy
Description: This program simulates a simple game of blackjack
"""

class Card:
    def __init__(self, suit, rank):
        """Create a new card object suit and rank"""
        self.suit = suit
        self.rank = rank
        # NOTE: __init__() methods NEVER have a return statement.

import random
class Deck:
    def __init__(self):
        """Create a new deck object"""
        self.deck = []
        self.current = 0
        suit = ""
        rank = ""
        for s in range(1, 5):
            if s == 1:
                suit = "hearts"
            elif s == 2:
                suit = "spades"
            elif s == 3:
                suit = "diamonds"
            elif s == 4:
                suit = "clubs"
            for r in range(1, 14):
                if r == 1:
                    rank = "ace"
                elif r == 11:
                    rank = "jack"
                elif r == 12:
                    rank = "queen"
                elif r == 13:
                    rank = "king"
                else: 
                    rank = str(r) 
                card = Card(suit, rank)
                self.deck.append(card)
        # NOTE: __init__() methods NEVER have a return statement.

    def shuffle(self):
        """The shuffle cards in deck."""
        random.shuffle(self.deck)
        self.current = 0

    def deal(self):
        """gets next card in deck."""
        card = self.deck[self.current]
        self.current += 1
        return card
        
class Hand:
    def __init__(self):
        """Create a new card object suit and rank"""
        self.cards = []
        # NOTE: __init__() methods NEVER have a return statement.

    def addCard(self, card):
        self.cards.append(card)

    def value(self):
        """The value of a card object."""
        val = 0
        aces = 0
        for card in self.cards:
            if card.rank == "ace":
                aces += 1
            elif card.rank == "jack" or card.rank == "queen" or card.rank == "king":
                val = val + 10  
            else:
                val = val + int(card.rank)  
        if aces > 0:  
            val = val + aces
            if val < 12:
                val = val + 10
        return val
    
    def __str__ (self):
        hand = ""
        for c in range(len(self.cards)):
            hand = hand + self.cards[c].rank + " of " + self.cards[c].suit
            if c < len(self.cards) - 1:
                hand = hand + ", "
        return hand
    
deal = "D"
while deal.upper() == "D":
    dealer = Hand()
    player = Hand()     
    deck = Deck()
    deck.shuffle()
    #deal cards to dealer and player
    for d in range(2):
        player.addCard(deck.deal())
        dealer.addCard(deck.deal())
        
    #show dealer top card
    print("Dealer shows: " + dealer.cards[1].rank + " of " + dealer.cards[1].suit)

    #show player hand
    print("Player holds: " + str(player))

    #player turn
    stand = False
    while player.value() < 22 and stand == False:
        choice = input("Enter H to hit or S to stand ")
        if choice.upper() == "S":
            stand = True
        elif choice.upper() == "H":
            print("Player taking card")
            player.addCard(deck.deal())
            print("Player holds: " + str(player))
        else:
            print("You must enter an S or H")

    #if player bust, hand over
    if player.value() > 21:
        print("Player busts, dealer wins")
    else:
        #dealer turn
        print("Dealer holds: " + str(dealer))
        stand = False
        while dealer.value() < 17:
            print("Dealer taking card")
            dealer.addCard(deck.deal())
            print("Dealer holds: " + str(dealer))
            
        if dealer.value() > 21:
            print("Dealer busts, player wins")
        elif player.value() == dealer.value():
            print("It's a push")
        elif player.value() > dealer.value():
            print("Player wins")
        else:
            print("Dealer wins")
    
    deal = ""
    while deal.upper() != "D" and deal.upper() != "Q":
        deal = input("Enter D to deal or Q to quit ")