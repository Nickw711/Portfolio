CREATE TABLE suppliers
( sup_id number(15) NOT NULL,
  sup_name varchar2(30) NOT NULL,
  contact_name varchar2(50) AGENT (contact_name),
  CONSTRAINT suppliers_pk PRIMARY KEY (sup_id)
);