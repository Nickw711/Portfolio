-- Nicholas Walsh 2/16/2021 M05_WalshNicholas_InsertInto
-- This script is a copy of the last script (M05_WalshNicholas_Alter) except the information has been inseted into the tables.
-- Again I have the Drop Table script to test the script and this would be deleted in the final version
DROP TABLE ProjectTask;
DROP TABLE Employee;
DROP TABLE Project;
DROP TABLE ProjDept;

CREATE TABLE ProjDept (
    ProjDeptID NUMBER(4) NOT NULL,
    ProjDeptName VARCHAR2(25 CHAR) NOT NULL,
    OfficeLocation VARCHAR2(10) NOT NULL,
    PhoneNumber VARCHAR2(12) NOT NULL,
    CONSTRAINT ProjDept_pk PRIMARY KEY (ProjDeptID)
);

CREATE TABLE Employee (
    EmployeeID NUMBER(2) NOT NULL,
    FirstName VARCHAR2(25 CHAR) NOT NULL,
    LastName VARCHAR2(25 CHAR) NOT NULL,
    ProjDeptID NUMBER(4) NOT NULL,
    PhoneNumber VARCHAR2(12) NOT NULL,
    CONSTRAINT Employee_pk PRIMARY KEY (EmployeeID),
    CONSTRAINT Employee_fk FOREIGN KEY (ProjDeptID) REFERENCES ProjDept(ProjDeptID)
);

CREATE TABLE Project (
    ProjectID NUMBER(3) NOT NULL,
    ProjectName VARCHAR2(25) NOT NULL,
    ProjDeptID NUMBER(4) NOT NULL,
    MaxHours NUMBER(3) NOT NULL,
    StartDate DATE NOT NULL,
    EndDate DATE,
    CONSTRAINT Project_pk PRIMARY KEY (ProjectID),
    CONSTRAINT Project_fk FOREIGN KEY (ProjDeptID) REFERENCES ProjDept (ProjDeptID)
);

CREATE TABLE ProjectTask (
    ProjectID NUMBER(4) NOT NULL,
    EmployeeID NUMBER(2) NOT NULL,
    TaskDetails VARCHAR2(50 CHAR),
    HoursWorked NUMBER(3) NOT NULL,
    CONSTRAINT ProjectTask_pk PRIMARY KEY (ProjectID, EmployeeID),
    CONSTRAINT ProjectTask_Project_fk FOREIGN KEY (ProjectID) REFERENCES Project (ProjectID),
    CONSTRAINT ProjectTask_Employee_fk FOREIGN KEY (EmployeeID) REFERENCES Employee (EmployeeID)
);

ALTER TABLE Employee
ADD EmailAddress VarChar2(25) UNIQUE NOT NULL;
-- In this section I inserted all ProjDept Data
INSERT INTO ProjDept (ProjDeptID, ProjDeptName, OfficeLocation, PhoneNumber)
VALUES (1001, 'Accounting', 'ITCC01-400', '888-285-8100' );
INSERT INTO ProjDept (ProjDeptID, ProjDeptName, OfficeLocation, PhoneNumber)
VALUES (2001, 'Human Resources', 'ITCC01-200', '888-285-8200');
INSERT INTO ProjDept (ProjDeptID, ProjDeptName, OfficeLocation, PhoneNumber)
VALUES (3001, 'Marketing', 'ITCC02-300', '888-285-8300');
INSERT INTO ProjDept (ProjDeptID, ProjDeptName, OfficeLocation, PhoneNumber)
VALUES (4001, 'Information Technology', 'ITCC02-100', '888-285-8400');
INSERT INTO ProjDept (ProjDeptID, ProjDeptName, OfficeLocation, PhoneNumber)
VALUES (5001, 'Legal', 'ITCC01-100', '888-285-8500');
--In this section I inserted all Employee Data
INSERT INTO Employee (EmployeeID, FirstName, LastName, ProjDeptID, PhoneNumber, EmailAddress)
VALUES (10, 'Mark', 'Columbus', 1001, '888-285-8101', 'mark@itcc.com');
INSERT INTO Employee (EmployeeID, FirstName, LastName, ProjDeptID, PhoneNumber, EmailAddress)
VALUES(29, 'Elvin', 'Wahl', 2001, '888-285-8201', 'elvin@itcc.com');
INSERT INTO Employee (EmployeeID, FirstName, LastName, ProjDeptID, PhoneNumber, EmailAddress)
VALUES (38, 'Taylor', 'Noel', 3001, '888-285-8303', 'taylor@itcc.com');
INSERT INTO Employee (EmployeeID, FirstName, LastName, ProjDeptID, PhoneNumber, EmailAddress)
VALUES (47, 'Ariel', 'Colby', 4001, '888-285-8401', 'ariel@itcc.com');
INSERT INTO Employee (EmployeeID, FirstName, LastName, ProjDeptID, PhoneNumber, EmailAddress)
VALUES (56, 'Riley', 'Peterson', 4001, '888-285-8402', 'riley@itcc.com');
INSERT INTO Employee (EmployeeID, FirstName, LastName, ProjDeptID, PhoneNumber, EmailAddress)
VALUES (65, 'Terence', 'Ferdinand', 1001, '888-285-8102', 'terence@itcc.com');
INSERT INTO Employee (EmployeeID, FirstName, LastName, ProjDeptID, PhoneNumber, EmailAddress)
VALUES (74, 'Bryce', 'Daley', 5001, '888-285-8501', 'bryce@itcc.com');
INSERT INTO Employee (EmployeeID, FirstName, LastName, ProjDeptID, PhoneNumber, EmailAddress)
VALUES (83, 'Eva', 'Myers', 2001, '888-285-8203', 'eva@itcc.com');
INSERT INTO Employee (EmployeeID, FirstName, LastName, ProjDeptID, PhoneNumber, EmailAddress)
VALUES (92, 'Lyn', 'Lorenzo', 3001, '888-285-8305', 'lyn@itcc.com');
INSERT INTO Employee (EmployeeID, FirstName, LastName, ProjDeptID, PhoneNumber, EmailAddress)
VALUES (11, 'Jamaal', 'Holt', 3001, '888-285-8307', 'jamaal@itcc.com');
-- In this section I inserted all Project Data (I could not figure out how you wanted me to do this with the code you provided so I made the month numerical)
INSERT INTO Project (ProjectID, ProjectName, ProjDeptId, MaxHours, StartDate, EndDate)
VALUES (901, 'Product Plan', 3001, 135, '05102012', '09152012');
INSERT INTO Project (ProjectID, ProjectName, ProjDeptId, MaxHours, StartDate, EndDate)
VALUES (902, 'Tax Preparation', 1001, 120, '07052012', '08102012');
INSERT INTO Project (ProjectID, ProjectName, ProjDeptId, MaxHours, StartDate, EndDate)
VALUES (903, 'Portfolio Analysis', 5001, 145, '08102012', '');
-- In this section I inserted all Project Task Data
INSERT INTO ProjectTask (ProjectID, EmployeeID, HoursWorked)
VALUES (901, 47, 30);
INSERT INTO ProjectTask (ProjectID, EmployeeID, HoursWorked)
VALUES (901, 56, 75);
INSERT INTO ProjectTask (ProjectID, EmployeeID, HoursWorked)
VALUES (901, 38, 55);
INSERT INTO ProjectTask (ProjectID, EmployeeID, HoursWorked)
VALUES (902, 65, 40);
INSERT INTO ProjectTask (ProjectID, EmployeeID, HoursWorked)
VALUES (902, 10, 45);
INSERT INTO ProjectTask (ProjectID, EmployeeID, HoursWorked)
VALUES (902, 74, 25);
INSERT INTO ProjectTask (ProjectID, EmployeeID, HoursWorked)
VALUES (903, 74, 20);
INSERT INTO ProjectTask (ProjectID, EmployeeID, HoursWorked)
VALUES (903, 83, 45);
INSERT INTO ProjectTask (ProjectID, EmployeeID, HoursWorked)
VALUES (903, 29, 40);
INSERT INTO ProjectTask (ProjectID, EmployeeID, HoursWorked)
VALUES (901, 74, 35);
INSERT INTO ProjectTask (ProjectID, EmployeeID, HoursWorked)
VALUES (902, 56, 80);