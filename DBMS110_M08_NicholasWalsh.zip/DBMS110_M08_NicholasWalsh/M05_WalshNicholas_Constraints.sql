-- Nicholas Walsh 2/16/2021 M05_WalshNicholas_Constraints
-- This script is a copy of the last script (M05_WalshNicholas_CreateTables) except the primary and foreign keys have been added
-- Again I have the Drop Table script to test the script and this would be deleted in the final version
DROP TABLE ProjectTask;
DROP TABLE Employee;
DROP TABLE Project;
DROP TABLE ProjDept;
-- In this section I made the ProjDeptID the ProjDept Primary Key
CREATE TABLE ProjDept (
    ProjDeptID NUMBER(4) NOT NULL,
    ProjDeptName VARCHAR2(25 CHAR) NOT NULL,
    OfficeLocation VARCHAR2(10) NOT NULL,
    PhoneNumber VARCHAR2(12) NOT NULL,
    CONSTRAINT ProjDept_pk PRIMARY KEY (ProjDeptID)
);
-- In this section I made the EmployeeID the Employee Primary Key and made the ProjDeptID the Foreign Key
CREATE TABLE Employee (
    EmployeeID NUMBER(2) NOT NULL,
    FirstName VARCHAR2(25 CHAR) NOT NULL,
    LastName VARCHAR2(25 CHAR) NOT NULL,
    ProjDeptID NUMBER(4) NOT NULL,
    PhoneNumber VARCHAR2(12) NOT NULL,
    CONSTRAINT Employee_pk PRIMARY KEY (EmployeeID),
    CONSTRAINT Employee_fk FOREIGN KEY (ProjDeptID) REFERENCES ProjDept(ProjDeptID)
);
-- In this section I made the ProjectID the Primary Key and made the ProjDeptID the Foreign Key 
CREATE TABLE Project (
    ProjectID NUMBER(3) NOT NULL,
    ProjectName VARCHAR2(25) NOT NULL,
    ProjDeptID NUMBER(4) NOT NULL,
    MaxHours NUMBER(3) NOT NULL,
    StartDate DATE NOT NULL,
    EndDate DATE,
    CONSTRAINT Project_pk PRIMARY KEY (ProjectID),
    CONSTRAINT Project_fk FOREIGN KEY (ProjDeptID) REFERENCES ProjDept (ProjDeptID)
);
-- In this section I made the ProjectID and the EmployeeID both the Primary Key and the Foreign Key
CREATE TABLE ProjectTask (
    ProjectID NUMBER(4) NOT NULL,
    EmployeeID NUMBER(2) NOT NULL,
    TaskDetails VARCHAR2(50 CHAR),
    HoursWorked NUMBER(3) NOT NULL,
    CONSTRAINT ProjectTask_pk PRIMARY KEY (ProjectID, EmployeeID),
    CONSTRAINT ProjectTask_Project_fk FOREIGN KEY (ProjectID) REFERENCES Project (ProjectID),
    CONSTRAINT ProjectTask_Employee_fk FOREIGN KEY (EmployeeID) REFERENCES Employee (EmployeeID)
)
