--Nicholas Walsh 3/4/2021 M07_WalshNicholas_Functions
--This script completes all commands assigned in the first part of M07 Lab Assignment.

-- This command shows the STUDENT_ID and their ELIGIBILITY_FOR_EXAMS from the STUDENT_ATTENDANCE table.
SELECT STUDENT_ID, ELIGIBILITY_FOR_EXAMS FROM STUDENT_ATTENDANCE;
--This command shows the STUDENT_ID and their GRADE if its 70 or above from the EXAM_RESULT table.
SELECT STUDENT_ID, GRADE FROM EXAM_RESULT WHERE GRADE >=70;
--710 is NINA's STUDENT_ID so this command shows NINA's highest GRADE on the EXAM_RESULT.
SELECT MAX(GRADE) FROM EXAM_RESULT WHERE STUDENT_ID=710;
--This command shows the least number of days off in the STUDENT_ATTENDANCE table.
SELECT MIN(NO_OF_DAYS_OFF) FROM STUDENT_ATTENDANCE
--This command shows the average grade of all the grades in the EXAM_RESULT table.
SELECT AVG(GRADE) FROM EXAM_RESULT;
--This command shows the average grade recieved in the OOAD course(188).
SELECT AVG(GRADE) FROM EXAM_RESULT WHERE COURSE_ID=188;