-- Nicholas Walsh 2/16/2021 M05_WalshNicholas_CreateTables
-- This script is going to create a database copy of the ERD shown on M05 Lab Assignment
--Added the drop table so you and I can make sure that the script works but it would be deleted in the final version
DROP TABLE ProjectTask;
DROP TABLE Employee;
DROP TABLE Project;
DROP TABLE ProjDept;
--This section will create the ProjDept table
CREATE TABLE ProjDept (
    ProjDeptID NUMBER(4) NOT NULL,
    ProjDeptName VARCHAR2(25 CHAR) NOT NULL,
    OfficeLocation VARCHAR2(10) NOT NULL,
    PhoneNumber VARCHAR2(12) NOT NULL
);
-- This section will create the Employee table
CREATE TABLE Employee (
    EmployeeID NUMBER(2) NOT NULL,
    FirstName VARCHAR2(25 CHAR) NOT NULL,
    LastName VARCHAR2(25 CHAR) NOT NULL,
    ProjDept NUMBER(4) NOT NULL,
    PhoneNumber VARCHAR2(12) NOT NULL
);
-- This section will create the Project table
CREATE TABLE Project (
    ProjectID NUMBER(3) NOT NULL,
    ProjectName VARCHAR2(25) NOT NULL,
    ProjDeptID NUMBER(4) NOT NULL,
    MaxHours NUMBER(3) NOT NULL,
    StartDate DATE NOT NULL,
    EndDate DATE
);
-- This section will create the ProjectTask table
CREATE TABLE ProjectTask (
    ProjectID NUMBER(4) NOT NULL,
    EmployeeID NUMBER(2) NOT NULL,
    TaskDetails VARCHAR2(50 CHAR),
    HoursWorked NUMBER(3) NOT NULL
)