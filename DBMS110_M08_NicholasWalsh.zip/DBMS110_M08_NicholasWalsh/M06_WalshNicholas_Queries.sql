-- Nicholas Walsh 2/24/2021 M06_WalshNicholas_Joins
-- This script executes all the commands assigned in the first part of the M06 Lab Assignment.
-- This first command shows the entire STUDENT table.
SELECT * FROM STUDENT;
-- This command shows all GRADEs and the STUDENT_IDs they're assigned to from the EXAM_RESULT table.
SELECT GRADE, STUDENT_ID FROM EXAM_RESULT;
-- This command shows the STUDENT_ID and their GRADE plus 7 in the EXAM_RESULT table.
SELECT STUDENT_ID, GRADE, GRADE+7 FROM EXAM_RESULT;
-- This command displays who each EMAIL_ADDR is assigned to in the format (EMAIL ADDRESS) is the email address of (NAME) in the STUDENT table.
SELECT EMAIL_ADDR || ' is the email address of ' || FIRST_NAME AS "Email" FROM STUDENT;
-- This command shows both the DEPARTMENT_NAME and HOD in the DEPARTMENT table.
SELECT DEPARTMENT_NAME, HOD FROM DEPARTMENT;
-- This command shows the DEPARTMENT_IDs in the COURSE table with no duplicates.
SELECT DISTINCT DEPARTMENT_ID FROM COURSE;
-- This command displays all COURSE table details during the spring session or where the SESSION_ID equals 100.
SELECT COURSE_ID, COURSE_NAME, SESSION_ID, DEPARTMENT_ID FROM COURSE WHERE SESSION_ID = 100;
-- This command shows all the EXAM_RESULT details where the grade is higher than 93.
SELECT STUDENT_ID, EXAM_ID, COURSE_ID, GRADE FROM EXAM_RESULT WHERE GRADE >93;
-- This command displays all the COURSE table details for DEPARTMENT_IDs 20 and 30.
SELECT COURSE_ID, COURSE_NAME, SESSION_ID, DEPARTMENT_ID FROM COURSE WHERE DEPARTMENT_ID IN (20,30);
-- This command displays all STUDENT table details of students with a name starting with the letter M.
SELECT STUDENT_ID, FIRST_NAME, PARENT_ID, STUDENT_REG_YEAR FROM STUDENT WHERE FIRST_NAME LIKE 'M%';
-- This command displays all STUDENT_COURSE table details of the students who have opted for course 190 and 193.
SELECT STUDENT_ID, COURSE_ID FROM STUDENT_COURSE WHERE COURSE_ID IN (190) OR COURSE_ID IN(193);
-- This command displays all COURSE table details where the DEPARTMENT_ID is 30 and the SESSION_ID is 200, which are none...
SELECT COURSE_ID, COURSE_NAME, SESSION_ID, DEPARTMENT_ID FROM COURSE WHERE DEPARTMENT_ID IN (30) AND SESSION_ID IN(200);