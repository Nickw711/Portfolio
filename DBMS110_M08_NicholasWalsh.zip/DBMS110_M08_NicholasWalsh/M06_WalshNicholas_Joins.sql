-- Nicholas Walsh 2/24/2021 M06_WalshNicholas_Joins
-- This script executes all the commands assigned in the second part of the M06 Lab Assignment.
-- The first command shows all the COURSE_NAMEs and their SESSION_IDs that are offered.
SELECT COURSE_NAME, SESSION_ID FROM COURSE;
-- This command shows the COURSE_NAMEs from the COURSE table of the courses that are offered during the spring session.
SELECT COURSE_NAME FROM COURSE WHERE SESSION_ID =(200);
-- This command joins both COURSE and STUDENT_COURSE tables and shows the COURSE_ID, COURSE_NAME, SESSION_ID, DEPARTMENT_ID, STUDENT_ID.
SELECT COURSE_ID, COURSE_NAME, SESSION_ID, DEPARTMENT_ID, STUDENT_ID FROM COURSE NATURAL JOIN STUDENT_COURSE;
--This command joins both COURSE and STUDENT tables and shows the COURSE_ID, COURSE_NAME, SESSION_ID, DEPARTMENT_ID, STUDENT_ID, and FIRST_NAME where the DEPARTMENT_ID is 30.
SELECT COURSE_ID, COURSE_NAME, SESSION_ID, DEPARTMENT_ID, STUDENT_ID, FIRST_NAME FROM COURSE NATURAL JOIN STUDENT WHERE DEPARTMENT_ID=(30);
-- This command was written incorrectly because only simple columns are allowed also the information was trying to be obtained from COURSE_NAME table when it should be obtained from COURSE table.
SELECT COURSE_NAME, GRADE, EXAM_ID FROM COURSE JOIN EXAM_RESULT USING (COURSE_ID);
-- This command is going to show you the COURSE_NAME, GRADE, and EXAM_ID of the courses between the numbers 190 and 195.
SELECT COURSE_NAME, GRADE, EXAM_ID
FROM COURSE d JOIN EXAM_RESULT a
ON a.COURSE_ID
BETWEEN 190 AND 195
-- This command is going to show you all the data in both EXAM_RESULT and EXAM_type tables in one table.
SELECT *
FROM EXAM_RESULT
CROSS JOIN EXAM_TYPE
