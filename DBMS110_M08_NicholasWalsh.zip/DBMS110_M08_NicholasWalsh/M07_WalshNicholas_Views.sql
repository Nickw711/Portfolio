--Nicholas Walsh 3/4/2021 M07_WalshNicholas_Views
--This script creates an SQL view called ParentInfoView to display the names of the parents for each student in the Academic Database.
--This command creates a view that shows the Father_Name and Mother_Name and to which student they are assigned to by the STUDENT_ID.
CREATE VIEW ParentInfoView AS SELECT p.Father_Name, p.Mother_Name, s.STUDENT_ID FROM PARENT_INFORMATION p, STUDENT s;